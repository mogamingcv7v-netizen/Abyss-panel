// plugins/settings.js - Bot Settings
import { config } from '../config.js';
import { settingsDB } from '../database.js';

export default {
  name: 'settings',
  command: ['settings', 'setting', 'اعدادات', 'ضبط'],
  aliases: ['set', 'اعد'],
  description: 'إعدادات البوت',
  owner: true, // فقط المالك
  
  async execute({ sock, m, args }) {
    if (!args[0]) {
      const currentSettings = `
⚙️ *إعدادات البوت الحالية:*

🎙️ *PTT (Voice Note):* ${settingsDB.data.ptt ? '✅ مفعل' : '❌ معطل'}
🎥 *PTV (Video Note):* ${settingsDB.data.ptv ? '✅ مفعل' : '❌ معطل'}
👁️ *Auto Read:* ${settingsDB.data.autoread ? '✅ مفعل' : '❌ معطل'}

👤 *الحقوق:*
• المطور: ${config.credits.developer}
• البوت: ${config.credits.botName}
      `;
      
      return m.sendButton(currentSettings, [
        { text: '🎙️ تبديل PTT', command: '.settings ptt' },
        { text: '🎥 تبديل PTV', command: '.settings ptv' },
        { text: '👁️ تبديل AutoRead', command: '.settings autoread' }
      ]);
    }
    
    const setting = args[0].toLowerCase();
    
    switch (setting) {
      case 'ptt':
        settingsDB.data.ptt = !settingsDB.data.ptt;
        await settingsDB.write();
        return m.reply(`🎙️ *PTT* ${settingsDB.data.ptt ? '✅ تم التفعيل' : '❌ تم التعطيل'}`);
        
      case 'ptv':
        settingsDB.data.ptv = !settingsDB.data.ptv;
        await settingsDB.write();
        return m.reply(`🎥 *PTV* ${settingsDB.data.ptv ? '✅ تم التفعيل' : '❌ تم التعطيل'}`);
        
      case 'autoread':
        settingsDB.data.autoread = !settingsDB.data.autoread;
        await settingsDB.write();
        return m.reply(`👁️ *Auto Read* ${settingsDB.data.autoread ? '✅ تم التفعيل' : '❌ تم التعطيل'}`);
        
      case 'credits':
      case 'حقوق':
        if (args[1]) {
          config.credits.developer = args.slice(1).join(' ');
          return m.reply(`👤 *تم تحديث الحقوق:* ${config.credits.developer}`);
        }
        return m.reply('❌ استخدم: .settings credits <الاسم الجديد>');
        
      default:
        return m.reply('❌ إعداد غير معروف');
    }
  }
};
