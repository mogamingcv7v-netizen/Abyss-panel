// plugins/elite.js - إدارة النخبة والمطورين
import { isElite, isDeveloper, isOwner, addElite, removeElite, addDeveloper, removeDeveloper, eliteDB, devDB } from '../database.js';

export default {
  name: 'elite',
  command: ['elite', 'addelite', 'delelite', 'adddev', 'deldev', 'listelite', 'listdev'],
  aliases: ['نخبة', 'اضف-نخبة', 'حذف-نخبة'],
  description: 'نظام النخبة والمطورين',
  
  async execute({ sock, m, args, cmd, isOwner, isElite: userIsElite }) {
    // عرض القائمة
    if (cmd === 'listelite') {
      let text = '👑 *قائمة النخبة:*\n\n';
      eliteDB.data.elites.forEach((e, i) => {
        text += `${i + 1}. @${e.jid.split('@')[0]} (${e.level || 'elite'})\n`;
      });
      return m.reply(text, { mentions: eliteDB.data.elites.map(e => e.jid) });
    }
    
    if (!m.quoted && !args[0]) {
      return m.reply('❌ منشن شخص أو اكتب رقمه');
    }
    
    const target = m.quoted ? m.quoted.sender : args[0] + '@s.whatsapp.net';
    
    // إضافة نخبة
    if (cmd === 'addelite' || cmd === 'نخبة') {
      if (!isOwner && !userIsElite) return m.reply('⛔ ليس لديك صلاحية');
      if (await addElite(sock, target, m.sender)) {
        return m.reply(`✅ تم إضافة @${target.split('@')[0]} للنخبة`, { mentions: [target] });
      } else {
        return m.reply('❌ المستخدم بالفعل في النخبة');
      }
    }
    
    // حذف نخبة
    if (cmd === 'delelite' || cmd === 'حذف-نخبة') {
      if (!isOwner) return m.reply('⛔ فقط المالك يمكنه الحذف');
      if (await removeElite(target)) {
        return m.reply(`✅ تم حذف @${target.split('@')[0]}`, { mentions: [target] });
      }
    }
  }
};