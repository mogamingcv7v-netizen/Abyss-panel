// plugins/menu.js - Menu Command
import { config, getCredits } from '../config.js';
import { plugins } from '../handler.js';

export default {
  name: 'menu',
  command: ['menu', 'help', 'قائمة', 'مساعدة', 'الاوامر'],
  aliases: ['start', 'begin', 'ابدأ'],
  
  async execute({ sock, m, args }) {
    const categories = {};
    
    // تصنيف الأوامر
    for (const [name, plugin] of plugins) {
      const category = plugin.category || 'أخرى';
      if (!categories[category]) categories[category] = [];
      categories[category].push(plugin);
    }
    
    let text = `${getCredits()}\n\n`;
    text += `*الأوامر المتاحة:*\n\n`;
    
    const sections = [];
    
    for (const [category, cmds] of Object.entries(categories)) {
      text += `*${category}:*\n`;
      const rows = [];
      
      cmds.forEach(cmd => {
        const commands = Array.isArray(cmd.command) ? cmd.command : [cmd.command];
        const cmdText = commands.map(c => `${config.prefix || '.'}${c}`).join(', ');
        text += `  ➤ ${cmdText}\n`;
        
        rows.push({
          title: commands[0],
          description: cmd.description || '',
          command: `${config.prefix || '.'}${commands[0]}`
        });
      });
      
      sections.push({
        title: category,
        rows: rows.slice(0, 10) // WhatsApp limit
      });
      
      text += '\n';
    }
    
    text += `\n💡 *نصيحة:* اضغط على الأزرار للاستخدام السريع`;
    
    return m.sendList(text, sections, { buttonText: '📂 الأقسام' });
  }
};
