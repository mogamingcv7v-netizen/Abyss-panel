// plugins/download.js - Universal Downloader (بدون rehund-scraper)
import axios from 'axios';
import ytdl from 'ytdl-core';
import ytSearch from 'yt-search';
import { createWriteStream, existsSync, mkdirSync, unlinkSync } from 'fs';
import { join } from 'path';
import { pipeline } from 'stream/promises';
import { config } from '../config.js';

export default {
  name: 'download',
  command: ['dl', 'download', 'yt', 'yta', 'ytv', 'تنزيل', 'يوتيوب'],
  aliases: ['play', 'song', 'فيديو', 'صوت'],
  description: 'تنزيل من YouTube',
  
  async execute({ sock, m, args, cmd }) {
    let query = args.join(' ');
    
    // استخراج من الرسالة المقتبسة
    if (!query && m.quoted) {
      query = m.quoted.text || m.quoted.caption;
    }
    
    if (!query) {
      return m.sendButton(
        '🔍 *حمل من YouTube*\n\n*الاستخدام:*\n• `.yt <رابط>` - تنزيل بالرابط\n• `.yt <اسم الأغنية>` - بحث وتنزيل',
        [
          { text: '🎵 بحث عن أغنية', command: '.yt ' },
          { text: '📺 بحث عن فيديو', command: '.ytv ' }
        ]
      );
    }
    
    const isVideo = cmd === 'ytv' || cmd === 'فيديو';
    
    try {
      await m.reply(`⏳ جاري ${isVideo ? 'البحث عن الفيديو' : 'البحث عن الصوت'}...`);
      
      let videoUrl = query;
      let videoInfo = null;
      
      // لو مش رابط، ابحث
      if (!ytdl.validateURL(query)) {
        const searchResults = await ytSearch(query);
        if (!searchResults.videos.length) {
          return m.reply('❌ لم يتم العثور على نتائج');
        }
        videoUrl = searchResults.videos[0].url;
        videoInfo = searchResults.videos[0];
      } else {
        videoInfo = await ytdl.getInfo(videoUrl);
        videoInfo = {
          title: videoInfo.videoDetails.title,
          author: { name: videoInfo.videoDetails.author.name },
          seconds: videoInfo.videoDetails.lengthSeconds,
          views: videoInfo.videoDetails.viewCount,
          thumbnail: videoInfo.videoDetails.thumbnails[0].url
        };
      }
      
      if (!videoInfo) return m.reply('❌ تعذر جلب المعلومات');
      
      await m.reply(`📥 جاري التنزيل: *${videoInfo.title}*`);
      
      const fileName = `yt_${Date.now()}.${isVideo ? 'mp4' : 'mp3'}`;
      const filePath = join(config.paths.temp, fileName);
      
      // إنشاء مجلد temp لو مش موجود
      if (!existsSync(config.paths.temp)) {
        mkdirSync(config.paths.temp, { recursive: true });
      }
      
      // تحميل
      const stream = ytdl(videoUrl, {
        quality: isVideo ? 'highest' : 'highestaudio',
        filter: isVideo ? 'audioandvideo' : 'audioonly'
      });
      
      await pipeline(stream, createWriteStream(filePath));
      
      // إرسال
      const caption = `✅ *تم التنزيل*\n\n🎵 *${videoInfo.title}*\n👤 ${videoInfo.author.name}\n⏱️ ${formatTime(videoInfo.seconds)}\n👁️ ${formatViews(videoInfo.views)}`;
      
      if (isVideo) {
        await sock.sendMessage(m.chat, {
          video: { url: filePath },
          caption,
          ptt: false
        }, { quoted: m.message });
      } else {
        await sock.sendMessage(m.chat, {
          audio: { url: filePath },
          mimetype: 'audio/mp4',
          ptt: config.messageSettings.ptt,
          caption
        }, { quoted: m.message });
      }
      
      // تنظيف
      setTimeout(() => {
        if (existsSync(filePath)) unlinkSync(filePath);
      }, 60000);
      
    } catch (err) {
      console.error('Download Error:', err);
      return m.reply(`❌ فشل التنزيل: ${err.message}`);
    }
  }
};

// مساعدات
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatViews(views) {
  if (views >= 1000000) return (views / 1000000).toFixed(1) + 'M';
  if (views >= 1000) return (views / 1000).toFixed(1) + 'K';
  return views;
}
