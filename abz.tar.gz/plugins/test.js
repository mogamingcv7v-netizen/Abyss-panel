// plugins/test.js - Speed Test Command
export default {
  name: 'test',
  command: ['test', 'ping', 'speed', 'p'],
  description: 'اختبار سرعة البوت',
  
  async execute({ sock, m }) {
    const startTime = Date.now();
    const responseTime = Date.now() - startTime;
    
    const text = `𝙰𝙸𝚉𝙴𝙽 𝙱𝙾𝚃 𝙸𝚂 𝚁𝙴𝙰𝙳𝚈🪽\n\n${responseTime} 𝚖𝚜`;
    
    await m.reply(text);
  }
};