// plugins/zarf.js - Zarf Command (Fixed Admin Check)
import { isElite, resolveJid } from '../database.js';
import { config } from '../config.js';
import { promises as fs } from 'fs';
import { join } from 'path';

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const zarfConfig = {
    reaction: { status: "on", emoji: "🫦" },
    group: {
        status: "on",
        descStatus: "on",
        newSubject: "Aizen مزروف",
        newDescription: `Aizen owns your area..\n\n𖠇 ${config.credits.developer}\n↬ https://whatsapp.com/channel/`
    },
    mention: { status: "on", text: "Aizen" },
    finalMessage: {
        status: "on",
        text: `Aizen owns your area..\n\n𖠇 ${config.credits.developer}\n↬ https://whatsapp.com/channel/`
    },
    audio: { status: "on" },
    video: { status: "on" },
};

const imagePath = join(config.paths.temp, "zarf-image.jpg");
const audioPath = join(config.paths.temp, "zarf-audio.mp3");
const videoPath = join(config.paths.temp, "zarf-video.mp4");

export default {
    name: 'zarf',
    command: ['zarf', 'هلا', 'hla', 'زرف'],
    aliases: ['تدمير', 'تخريب'],
    description: 'زرف المجموعة بالكامل',
    category: 'admin',
    elite: true,
    dev: false,
    group: true,
    
    async execute({ sock, m, args, isElite: userIsElite, isOwner }) {
        const jid = m.chat;
        const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        
        // ✅ التحقق من الإشراف يدوياً (مع دعم LID)
        const meta = await sock.groupMetadata(jid);
        
        // حول الـ sender لـ PN لو LID
        const userId = await resolveJid(sock, m.sender);
        
        const userParticipant = meta.participants.find(p => p.id === userId || p.id === m.sender);
        const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin';
        
        const botParticipant = meta.participants.find(p => p.id === botJid);
        const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
        
        // Debug (شيله بعد ما يشتغل)
        console.log('👤 User ID:', m.sender, '->', userId);
        console.log('👤 Is Admin:', isUserAdmin);
        console.log('🤖 Bot Is Admin:', isBotAdmin);
        
        if (!isUserAdmin && !isOwner) {
            return m.reply('⛔ هذا الأمر للمشرفين فقط\n\n(أو أضف نفسك للنخبة Elite)');
        }
        
        if (!isBotAdmin) {
            return m.reply('⛔ البوت يحتاج لصلاحيات مشرف (Admin)\n\n🔧 اجعل البوت مشرفاً في الإعدادات > مشرفين المجموعة');
        }

        const text = args.join(" ").trim();

        // ── معالجة الأزرار ──
        if (text === "zarf_only") {
            return await m.reply("✅ تم الاقتصار على الزرف فقط.");
        }

        if (text === "zarf_end") {
            await m.reply("⚠️ جاري طرد جميع الأعضاء...");
            const members = meta.participants.map(p => p.id).filter(id => id !== botJid);
            for (let i = 0; i < members.length; i += 30) {
                await sock.groupParticipantsUpdate(jid, members.slice(i, i + 30), "remove").catch(() => {});
                await sleep(2000);
            }
            return await m.reply("✅ تم طرد جميع الأعضاء.");
        }

        // ── تفاعل ──
        if (zarfConfig.reaction.status === "on") {
            await sock.sendMessage(jid, { react: { text: zarfConfig.reaction.emoji, key: m.key } }).catch(() => {});
        }

        // ── قراءة الصورة ──
        let imgBuffer = null;
        try { imgBuffer = await fs.readFile(imagePath); } catch(e) {}

        // ── تحديد الترقية والتنزيل ──
        const demote = [], promote = [];
        for (const member of meta.participants) {
            if (member.id === botJid) continue;
            const memberIsElite = await isElite(sock, member.id);
            if (member.admin && !memberIsElite) demote.push(member.id);
            if (!member.admin && memberIsElite) promote.push(member.id);
        }

        // ── تنفيذ المهام ──
        const tasks = [];
        if (demote.length) tasks.push(sock.groupParticipantsUpdate(jid, demote, "demote").catch(() => {}));
        if (promote.length) tasks.push(sock.groupParticipantsUpdate(jid, promote, "promote").catch(() => {}));
        if (!meta.announce) tasks.push(sock.groupSettingUpdate(jid, "announcement").catch(() => {}));
        if (zarfConfig.group.status === "on") {
            tasks.push(sock.groupUpdateSubject(jid, zarfConfig.group.newSubject).catch(() => {}));
            tasks.push(sock.groupUpdateDescription(jid, zarfConfig.group.newDescription).catch(() => {}));
        }
        if (imgBuffer) tasks.push(sock.updateProfilePicture(jid, imgBuffer).catch(() => {}));
        if (zarfConfig.mention.status === "on") {
            tasks.push(sock.sendMessage(jid, { text: zarfConfig.mention.text, mentions: meta.participants.map(p => p.id) }).catch(() => {}));
        }
        if (zarfConfig.finalMessage.status === "on") {
            tasks.push(sock.sendMessage(jid, { text: zarfConfig.finalMessage.text }).catch(() => {}));
        }

        // الصوت والفيديو
        if (zarfConfig.audio.status === "on") {
            const buf = await fs.readFile(audioPath).catch(() => null);
            if (buf) tasks.push(sock.sendMessage(jid, { audio: buf, mimetype: "audio/mpeg", ptt: true }).catch(() => {}));
        }
        if (zarfConfig.video.status === "on") {
            const buf = await fs.readFile(videoPath).catch(() => null);
            if (buf) tasks.push(sock.sendMessage(jid, { video: buf, mimetype: "video/mp4", ptv: true }).catch(() => {}));
        }

        await Promise.all(tasks);

        // ── الأزرار ──
        const caption = "تم تنفيذ الزرف بنجاح ✅\nاختر الإجراء المناسب:";
        await sock.sendMessage(jid, {
            text: caption,
            footer: `${config.credits.botName} - ZARF`,
            buttonText: "🎯 أكمل الزرف",
            sections: [{
                title: "اختر الإجراء:",
                rows: [
                    { title: "زرف فقط ✅", description: "الاقتصار على الزرف الحالي", id: ".zarf zarf_only" },
                    { title: "𝐄𝐍𝐃 ⚠️", description: "طرد جميع الأعضاء", id: ".zarf zarf_end" }
                ]
            }],
            mentions: [m.sender]
        }, { quoted: m.key });
    }
};