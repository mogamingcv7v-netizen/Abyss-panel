// plugins/filemanager.js - Advanced File Manager
import { 
  readdirSync, 
  statSync, 
  readFileSync, 
  writeFileSync,
  mkdirSync,
  rmdirSync,
  unlinkSync,
  renameSync,
  existsSync
} from 'fs';
import { join, resolve, basename, dirname, extname } from 'path';
import { config } from '../config.js';

// تتبع المسارات الحالية للمستخدمين
const userPaths = new Map();

export default {
  name: 'filemanager',
  command: ['fm', 'file', 'files', 'فم', 'ملف'],
  aliases: ['filemanager', 'مدير-الملفات', 'فايل'],
  description: 'مدير الملفات المتقدم',
  elite: true, // فقط النخبة
  
  async execute({ sock, m, args, cmd }) {
    const userId = m.sender;
    const currentPath = userPaths.get(userId) || process.cwd();
    
    // إذا مفيش أوامر، اعرض الواجهة الرئيسية
    if (!args[0]) {
      return showMainMenu(m, currentPath);
    }
    
    const subCmd = args[0].toLowerCase();
    const target = args[1];
    
    try {
      switch (subCmd) {
        case 'list':
        case 'ls':
        case 'عرض':
          return await listFiles(m, currentPath);
          
        case 'cd':
        case 'دخول':
          if (!target) return m.reply('❌ حدد اسم المجلد');
          const newPath = join(currentPath, target);
          if (!existsSync(newPath) || !statSync(newPath).isDirectory()) {
            return m.reply('❌ المجلد غير موجود');
          }
          userPaths.set(userId, newPath);
          return await listFiles(m, newPath, `✅ تم الدخول لـ: ${target}`);
          
        case 'back':
        case 'خروج':
        case '..':
          const parent = dirname(currentPath);
          if (parent === currentPath) return m.reply('❌ أنت في المجلد الجذر');
          userPaths.set(userId, parent);
          return await listFiles(m, parent, '✅ تم الخروج للمجلد السابق');
          
        case 'read':
        case 'cat':
        case 'قراءة':
          if (!target) return m.reply('❌ حدد اسم الملف');
          return await readFile(m, join(currentPath, target));
          
        case 'edit':
        case 'write':
        case 'تعديل':
          if (!target || args.length < 3) {
            return m.reply('❌ الاستخدام: .fm edit <اسم_الملف> <المحتوى>');
          }
          const content = args.slice(2).join(' ');
          return await editFile(m, join(currentPath, target), content);
          
        case 'mkdir':
        case 'mkfolder':
        case 'مجلد-جديد':
          if (!target) return m.reply('❌ حدد اسم المجلد');
          return await createFolder(m, join(currentPath, target));
          
        case 'touch':
        case 'mkfile':
        case 'ملف-جديد':
          if (!target) return m.reply('❌ حدد اسم الملف');
          return await createFile(m, join(currentPath, target));
          
        case 'rm':
        case 'del':
        case 'حذف':
          if (!target) return m.reply('❌ حدد اسم الملف أو المجلد');
          return await deleteItem(m, join(currentPath, target));
          
        case 'rename':
        case 'mv':
        case 'تسمية':
          if (!target || !args[2]) {
            return m.reply('❌ الاستخدام: .fm rename <القديم> <الجديد>');
          }
          return await renameItem(m, 
            join(currentPath, target), 
            join(currentPath, args[2])
          );
          
        case 'path':
        case 'pwd':
          return m.reply(`📍 *المسار الحالي:*\n\`${currentPath}\``);
          
        default:
          return showMainMenu(m, currentPath);
      }
    } catch (err) {
      return m.reply(`❌ خطأ: ${err.message}`);
    }
  }
};

// عرض القائمة الرئيسية
async function showMainMenu(m, currentPath) {
  const relativePath = currentPath.replace(process.cwd(), '.') || '.';
  
  const buttons = [
    { text: '📂 عرض الملفات', command: '.fm list' },
    { text: '⬅️ خروج', command: '.fm back' },
    { text: '📍 المسار الحالي', command: '.fm path' }
  ];
  
  const sections = [{
    title: '📁 إدارة المجلدات',
    rows: [
      { title: '📂 دخول مجلد', description: 'cd <اسم>', command: '.fm cd ' },
      { title: '📁 مجلد جديد', description: 'mkdir <اسم>', command: '.fm mkdir ' }
    ]
  }, {
    title: '📄 إدارة الملفات',
    rows: [
      { title: '📖 قراءة ملف', description: 'read <اسم>', command: '.fm read ' },
      { title: '✏️ تعديل ملف', description: 'edit <اسم> <محتوى>', command: '.fm edit ' },
      { title: '📄 ملف جديد', description: 'touch <اسم>', command: '.fm touch ' },
      { title: '🗑️ حذف', description: 'rm <اسم>', command: '.fm rm ' },
      { title: '✏️ تسمية', description: 'rename <قديم> <جديد>', command: '.fm rename ' }
    ]
  }];
  
  return m.sendList(
    `🗂️ *مدير الملفات*\n\n📍 المسار: \`${relativePath}\`\n\nاختر إجراء:`,
    sections,
    { buttonText: '⚙️ الخيارات' }
  );
}

// عرض الملفات
async function listFiles(m, path, customMsg = null) {
  const items = readdirSync(path);
  let text = customMsg || `📂 *محتويات المجلد:*\n\n`;
  
  const folders = [];
  const files = [];
  
  items.forEach(item => {
    const fullPath = join(path, item);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      folders.push(`📁 ${item}/`);
    } else {
      const size = formatBytes(stat.size);
      files.push(`📄 ${item} (${size})`);
    }
  });
  
  text += folders.join('\n');
  if (folders.length && files.length) text += '\n';
  text += files.join('\n');
  
  if (items.length === 0) text += '📭 المجلد فارغ';
  
  // أزرار سريعة
  const buttons = items.slice(0, 3).map(item => ({
    text: `📂 ${item}`,
    command: `.fm cd ${item}`
  }));
  
  buttons.push({ text: '🔄 تحديث', command: '.fm list' });
  buttons.push({ text: '⬅️ خروج', command: '.fm back' });
  
  return m.sendButton(text, buttons);
}

// قراءة ملف
async function readFile(m, filePath) {
  if (!existsSync(filePath)) return m.reply('❌ الملف غير موجود');
  
  const stat = statSync(filePath);
  if (stat.isDirectory()) return m.reply('❌ هذا مجلد، ليس ملف');
  
  const ext = extname(filePath).toLowerCase();
  const content = readFileSync(filePath, 'utf-8');
  const preview = content.length > 1000 ? content.substring(0, 1000) + '...\n\n(تم اقتصاص المحتوى)' : content;
  
  const buttons = [
    { text: '✏️ تعديل', command: `.fm edit ${basename(filePath)} ` },
    { text: '🗑️ حذف', command: `.fm rm ${basename(filePath)}` },
    { text: '⬅️ رجوع', command: '.fm list' }
  ];
  
  return m.sendButton(
    `📄 *${basename(filePath)}*\n📏 الحجم: ${formatBytes(stat.size)}\n\n\`\`\`${ext}\n${preview}\n\`\`\``,
    buttons
  );
}

// تعديل ملف
async function editFile(m, filePath, content) {
  writeFileSync(filePath, content);
  return m.reply(`✅ تم تعديل الملف: ${basename(filePath)}`);
}

// إنشاء مجلد
async function createFolder(m, folderPath) {
  mkdirSync(folderPath, { recursive: true });
  return m.reply(`✅ تم إنشاء المجلد: ${basename(folderPath)}`);
}

// إنشاء ملف
async function createFile(m, filePath) {
  writeFileSync(filePath, '');
  return m.reply(`✅ تم إنشاء الملف: ${basename(filePath)}`);
}

// حذف عنصر
async function deleteItem(m, itemPath) {
  if (!existsSync(itemPath)) return m.reply('❌ العنصر غير موجود');
  
  const stat = statSync(itemPath);
  if (stat.isDirectory()) {
    rmdirSync(itemPath);
  } else {
    unlinkSync(itemPath);
  }
  
  return m.reply(`🗑️ تم الحذف: ${basename(itemPath)}`);
}

// تسمية عنصر
async function renameItem(m, oldPath, newPath) {
  renameSync(oldPath, newPath);
  return m.reply(`✅ تم التسمية من ${basename(oldPath)} إلى ${basename(newPath)}`);
}

// تنسيق الحجم
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
