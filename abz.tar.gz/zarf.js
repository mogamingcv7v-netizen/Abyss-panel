// plugins/zarf.js - Zarf Command for Aizen Bot
import { isElite } from '../database.js';
import { config } from '../config.js';
import { promises as fsPromises } from 'fs';
import { join } from 'path';

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// إعدادات الزرف
const zarfConfig = {
    reaction: { status: "on", emoji: "🫦" },
    group: {
        status: "on",
        descStatus: "on",
        newSubject: "Aizen مزروف",
        newDescription:
            `Aizen owns your area..\n\n` +
            `مابقول لك مين Aizen، قرب وبتعرفه كويس..\n\n` +
            `تبي تعرف كيف انزرفت..؟\n` +
            `اجابتك بتنزل هنا قريب\n\n` +
            `𖠇 ${config.credits.developer}\n↬ https://whatsapp.com/channel/\n\n______`
    },
    mention: { status: "on", text: "Aizen" },
    finalMessage: {
        status: "on",
        text:
            `Aizen owns your area..\n\n` +
            `مابقول لك مين Aizen، قرب وبتعرفه كويس..\n\n` +
            `تبي تعرف كيف انزرفت..؟\n` +
            `اجابتك بتنزل هنا قريب\n\n` +
            `𖠇 ${config.credits.developer}\n↬ https://whatsapp.com/channel/\n\n______`
    },
    audio: { status: "on" },
    video: { status: "on" },
};

// مسارات الملفات (معدلة للبوت الجديد)
const imagePath = join(config.paths.temp, "zarf-image.jpg");
const audioPath = join(config.paths.temp, "zarf-audio.mp3");
const videoPath = join(config.paths.temp, "zarf-video.mp4");

// طرد جميع الأعضاء
async function kickAll(sock, jid, botJid) {
    const meta = await sock.groupMetadata(jid);
    const members = meta.participants.map(p => p.id).filter(id => id !== botJid);
    
    for (let i = 0; i < members.length; i += 30) {
        await sock.groupParticipantsUpdate(jid, members.slice(i, i + 30), "remove").catch(() => {});
        await sleep(2000);
    }
}

export default {
    name: 'zarf',
    command: ['zarf', 'هلا', 'hla', 'زرف'],
    aliases: ['تدمير', 'تخريب'],
    description: 'زرف المجموعة بالكامل (تغيير الصورة والوصف وطرد الأعضاء)',
    category: 'admin',
    elite: true, // ✅ تغيير من "on" لـ true
    dev: false,  // ✅ تغيير من "off" لـ false
    group: true, // ✅ للجروبات فقط
    admin: true, // ✅ يحتاج مشرف
    botAdmin: true, // ✅ البوت يحتاج مشرف
    
    async execute({ sock, m, args, isElite: userIsElite, isOwner, isDeveloper }) {
        const jid = m.chat;
        const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const text = args.join(" ").trim();

        // ── معالجة ضغط الأزرار ──
        if (text === "zarf_only") {
            return await m.reply("✅ تم الاقتصار على الزرف فقط.");
        }

        if (text === "zarf_end") {
            await m.reply("⚠️ جاري طرد جميع الأعضاء...");
            await kickAll(sock, jid, botJid);
            return await m.reply("✅ تم طرد جميع الأعضاء.");
        }

        // ── تفاعل سريع ──
        if (zarfConfig.reaction.status === "on") {
            await sock.sendMessage(jid, {
                react: { text: zarfConfig.reaction.emoji, key: m.key }
            }).catch(() => {});
        }

        // ── بيانات المجموعة ──
        const meta = await sock.groupMetadata(jid);
        const members = meta.participants;

        // ── قراءة الصورة ──
        let imgBuffer = null;
        try { 
            imgBuffer = await fsPromises.readFile(imagePath); 
        } catch(e) {
            console.log('⚠️ Image not found:', imagePath);
        }

        // ── تحديد الترقية والتنزيل ──
        const demote = [], promote = [];
        
        // ✅ التحقق من Elite بشكل صحيح (مع LID support)
        for (const member of members) {
            if (member.id === botJid) continue;
            
            // ✅ استخدام isElite الصحيحة (async مع sock)
            const memberIsElite = await isElite(sock, member.id);
            
            if (member.admin && !memberIsElite) demote.push(member.id);
            if (!member.admin && memberIsElite) promote.push(member.id);
        }

        // ── تنفيذ كل المهام بالتوازي ──
        const tasks = [];

        if (demote.length) tasks.push(sock.groupParticipantsUpdate(jid, demote, "demote").catch(() => {}));
        if (promote.length) tasks.push(sock.groupParticipantsUpdate(jid, promote, "promote").catch(() => {}));
        if (!meta.announce) tasks.push(sock.groupSettingUpdate(jid, "announcement").catch(() => {}));

        if (zarfConfig.group.status === "on") {
            if (zarfConfig.group.newSubject)
                tasks.push(sock.groupUpdateSubject(jid, zarfConfig.group.newSubject).catch(() => {}));
            if (zarfConfig.group.descStatus === "on" && zarfConfig.group.newDescription)
                tasks.push(sock.groupUpdateDescription(jid, zarfConfig.group.newDescription).catch(() => {}));
        }

        if (imgBuffer)
            tasks.push(sock.updateProfilePicture(jid, imgBuffer).catch(() => {}));

        if (zarfConfig.mention.status === "on")
            tasks.push(sock.sendMessage(jid, {
                text: zarfConfig.mention.text,
                mentions: members.map(p => p.id)
            }).catch(() => {}));

        if (zarfConfig.finalMessage.status === "on")
            tasks.push(sock.sendMessage(jid, {
                text: zarfConfig.finalMessage.text
            }).catch(() => {}));

        // ── الصوت والفيديو ──
        if (zarfConfig.audio.status === "on") {
            const buf = await fsPromises.readFile(audioPath).catch(() => null);
            if (buf) tasks.push(sock.sendMessage(jid, {
                audio: buf, 
                mimetype: "audio/mpeg",
                ptt: true // ✅ صوتي
            }).catch(() => {}));
        }
        
        if (zarfConfig.video.status === "on") {
            const buf = await fsPromises.readFile(videoPath).catch(() => null);
            if (buf) tasks.push(sock.sendMessage(jid, {
                video: buf, 
                mimetype: "video/mp4", 
                ptv: true // ✅ فيديو دائري
            }).catch(() => {}));
        }

        await Promise.all(tasks);

        // ── الأزرار التفاعلية (صيغة @itsliaaa/baileys) ──
        const caption = imgBuffer ? 
            "تم تنفيذ الزرف بنجاح ✅\nاختر الإجراء المناسب:" : 
            "تم تنفيذ الزرف بنجاح ✅\nاختر الإجراء المناسب:";

        // ✅ أزرار بصيغة البوت الجديد (nativeFlow)
        const buttons = [
            { 
                text: '🎯 أكمل الزرف', 
                sections: [{
                    title: "اختر الإجراء:",
                    rows: [
                        { title: "زرف فقط ✅", description: "الاقتصار على الزرف الحالي", id: ".zarf zarf_only" },
                        { title: "𝐄𝐍𝐃 ⚠️", description: "طرد جميع الأعضاء", id: ".zarf zarf_end" }
                    ]
                }]
            }
        ];

        if (imgBuffer) {
            await sock.sendMessage(jid, {
                image: imgBuffer,
                caption: caption,
                footer: `${config.credits.botName} - ZARF`,
                buttonText: "🎯 أكمل الزرف",
                sections: buttons[0].sections,
                mentions: [m.sender]
            }, { quoted: m.key });
        } else {
            await sock.sendMessage(jid, {
                text: caption,
                footer: `${config.credits.botName} - ZARF`,
                buttonText: "🎯 أكمل الزرف",
                sections: buttons[0].sections,
                mentions: [m.sender]
            }, { quoted: m.key });
        }
    }
};