// handler.js - كامل مع دعم LID
import { config } from './config.js';
import { isElite, isDeveloper, isOwner } from './database.js';
import { readdirSync } from 'fs';
import { join } from 'path';
import { pathToFileURL } from 'url';

export const plugins = new Map();
export const aliases = new Map();

export const loadPlugins = async (pluginsPath) => {
  plugins.clear(); aliases.clear();
  const loadDir = async (basePath = '') => {
    const entries = readdirSync(join(pluginsPath, basePath), { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = join(basePath, entry.name);
      if (entry.isDirectory()) await loadDir(fullPath);
      else if (entry.name.endsWith('.js')) {
        try {
          const filePath = join(pluginsPath, fullPath);
          const module = await import(pathToFileURL(filePath).href + '?t=' + Date.now());
          if (module.default?.command) {
            const plugin = module.default, name = plugin.name || entry.name.replace('.js', '');
            plugins.set(name, plugin);
            if (Array.isArray(plugin.command)) plugin.command.forEach(c => aliases.set(c, name));
            else aliases.set(plugin.command, name);
            if (plugin.aliases) plugin.aliases.forEach(a => aliases.set(a, name));
          }
        } catch (err) { console.error(`❌ ${entry.name}: ${err.message}`); }
      }
    }
  };
  await loadDir();
  console.log(`✅ Plugins: ${plugins.size} | Commands: ${aliases.size}`);
};

export const handler = async (sock, msg, store) => {
  try {
    if (!msg.message) return;
    const m = serializeMessage(sock, msg);
    if (!m.text) return;
    
    const prefix = config.prefix || '.';
    if (!m.text.startsWith(prefix)) return;
    
    const args = m.text.slice(prefix.length).trim().split(/ +/);
    const cmd = args.shift().toLowerCase();
    const pluginName = aliases.get(cmd);
    if (!pluginName) return;
    
    const plugin = plugins.get(pluginName);
    if (!plugin) return;
    
    // ✅ التحقق من الصلاحيات (Async مع LID)
    const userIsOwner = config.ownerNumber.some(num => m.sender.includes(num.split('@')[0])) || isOwner(m.sender);
    const userIsElite = await isElite(sock, m.sender);
    const userIsDev = await isDeveloper(sock, m.sender);
    
    if (plugin.owner && !userIsOwner) return m.reply('⛔ للمالك فقط');
    if (plugin.elite && !userIsElite && !userIsOwner) return m.reply('⛔ للنخبة فقط');
    if (plugin.dev && !userIsDev && !userIsElite && !userIsOwner) return m.reply('⛔ للمطورين فقط');
    if (plugin.group && !m.isGroup) return m.reply('⛔ للمجموعات فقط');
    
    if (m.isGroup && (plugin.admin || plugin.botAdmin)) {
      try {
        const meta = await sock.groupMetadata(m.chat);
        m.isAdmin = meta.participants.find(p => p.id === m.sender)?.admin != null;
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        m.isBotAdmin = meta.participants.find(p => p.id === botId)?.admin != null;
      } catch (e) { m.isAdmin = m.isBotAdmin = false; }
    }
    
    if (plugin.admin && !m.isAdmin) return m.reply('⛔ للمشرفين فقط');
    if (plugin.botAdmin && !m.isBotAdmin) return m.reply('⛔ البوت يحتاج مشرف');
    
    await plugin.execute({ sock, m, args, cmd, prefix, plugins, store, config, isElite: userIsElite, isDeveloper: userIsDev, isOwner: userIsOwner });
  } catch (err) { console.error('Handler Error:', err); }
};

export const handleButtonResponse = async (sock, msg) => {
  try {
    const id = msg.message?.buttonsResponseMessage?.selectedButtonId || msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId;
    if (!id) return;
    await handler(sock, { ...msg, message: { conversation: id } }, null);
  } catch (err) { console.error('Button Error:', err); }
};

const serializeMessage = (sock, msg) => {
  const m = {};
  m.key = msg.key; m.id = msg.key.id; m.chat = msg.key.remoteJid; m.fromMe = msg.key.fromMe;
  m.sender = msg.key.participant || msg.key.remoteJid;
  m.pushName = msg.pushName || ''; m.message = msg.message; m.timestamp = msg.messageTimestamp;
  m.type = Object.keys(msg.message)[0];
  m.text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || msg.message?.imageMessage?.caption || msg.message?.videoMessage?.caption || msg.message?.buttonsResponseMessage?.selectedButtonId || msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId || '';
  m.isGroup = m.chat?.endsWith('@g.us') || false; m.isAdmin = false; m.isBotAdmin = false;
  const ctx = msg.message?.extendedTextMessage?.contextInfo;
  m.quoted = ctx?.quotedMessage ? { key: { remoteJid: m.chat, fromMe: ctx.participant === m.sender, id: ctx.stanzaId, participant: ctx.participant }, message: ctx.quotedMessage, sender: ctx.participant } : null;
  m.reply = (text, opts = {}) => sock.sendMessage(m.chat, { text, ...opts }, { quoted: msg });
  m.sendButton = (text, btns, opts = {}) => sock.sendMessage(m.chat, { text, footer: `© ${config.credits.developer}`, buttons: btns.map(b => ({ text: b.text, id: b.id || b.command })), ...opts }, { quoted: msg });
  m.sendList = (text, secs, opts = {}) => sock.sendMessage(m.chat, { text, footer: `© ${config.credits.developer}`, buttonText: opts.buttonText || 'اختر', sections: secs.map(s => ({ title: s.title, rows: s.rows.map(r => ({ title: r.title, description: r.description || '', rowId: r.command || r.id })) })), ...opts }, { quoted: msg });
  return m;
};