// database.js - كامل مع LID Support
import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import { join } from 'path';
import { config } from './config.js';

const adapter = new JSONFile(join(config.paths.database, 'database.json'));
const eliteAdapter = new JSONFile(join(config.paths.database, 'elite.json'));
const devAdapter = new JSONFile(join(config.paths.database, 'developers.json'));
const settingsAdapter = new JSONFile(join(config.paths.database, 'settings.json'));

export const db = new Low(adapter, { users: {}, groups: {}, sessions: {} });
export const eliteDB = new Low(eliteAdapter, { elites: [], banned: [] });
export const devDB = new Low(devAdapter, { developers: [], banned: [] });
export const settingsDB = new Low(settingsAdapter, { ptt: true, ptv: false, autoread: false });

// Cache للـ LID
const lidCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

const getCached = (jid) => {
  const c = lidCache.get(jid);
  if (c && Date.now() - c.time < CACHE_TTL) return c.data;
  return null;
};

const setCached = (jid, data) => lidCache.set(jid, { data, time: Date.now() });

// تحويل LID لـ PN
export const resolveJid = async (sock, jid) => {
  if (!jid?.endsWith('@lid')) return jid;
  const cached = getCached(jid);
  if (cached) return cached.phoneNumber || jid;
  try {
    const result = await sock.findUserId(jid);
    if (result?.phoneNumber !== 'id-not-found') {
      setCached(jid, result);
      return result.phoneNumber;
    }
  } catch (e) {}
  return jid;
};

// تحميل الداتابيز
export const loadDatabases = async () => {
  await db.read(); await eliteDB.read(); await devDB.read(); await settingsDB.read();
  const ownerJid = config.ownerNumber[0];
  if (!eliteDB.data.elites.find(e => e.jid === ownerJid)) {
    eliteDB.data.elites.push({ jid: ownerJid, addedBy: 'system', date: new Date().toISOString(), level: 'owner', type: 'pn' });
    await eliteDB.write();
  }
  if (!devDB.data.developers.find(d => d.jid === ownerJid)) {
    devDB.data.developers.push({ jid: ownerJid, addedBy: 'system', date: new Date().toISOString(), level: 'owner', type: 'pn' });
    await devDB.write();
  }
};

// البحث في DB (يدعم LID)
const checkDb = async (sock, jid, arr) => {
  if (arr.find(x => x.jid === jid)) return true;
  if (jid?.endsWith('@lid') && sock) {
    const pn = await resolveJid(sock, jid);
    if (pn !== jid && arr.find(x => x.jid === pn)) return true;
  }
  return false;
};

// دوال التحقق
export const isElite = async (sock, jid) => {
  if (!jid) return false;
  if (config.ownerNumber.includes(jid)) return true;
  return await checkDb(sock, jid, eliteDB.data.elites);
};

export const isDeveloper = async (sock, jid) => {
  if (!jid) return false;
  if (config.ownerNumber.includes(jid)) return true;
  return await checkDb(sock, jid, devDB.data.developers);
};

export const isOwner = (jid) => config.ownerNumber.includes(jid);

// تحويل قبل الحفظ
const normalizeForSave = async (sock, jid) => {
  if (jid?.endsWith('@lid') && sock) {
    const pn = await resolveJid(sock, jid);
    return pn !== jid ? pn : jid;
  }
  return jid;
};

export const addElite = async (sock, jid, addedBy) => {
  const finalJid = await normalizeForSave(sock, jid);
  if (eliteDB.data.elites.find(e => e.jid === finalJid)) return false;
  eliteDB.data.elites.push({ jid: finalJid, addedBy, date: new Date().toISOString(), level: 'elite', type: finalJid.endsWith('@lid') ? 'lid' : 'pn' });
  await eliteDB.write();
  return true;
};

export const removeElite = async (jid) => {
  const idx = eliteDB.data.elites.findIndex(e => e.jid === jid);
  if (idx === -1) return false;
  eliteDB.data.elites.splice(idx, 1);
  await eliteDB.write();
  return true;
};

export const addDeveloper = async (sock, jid, addedBy, level = 'dev') => {
  const finalJid = await normalizeForSave(sock, jid);
  if (devDB.data.developers.find(d => d.jid === finalJid)) return false;
  devDB.data.developers.push({ jid: finalJid, addedBy, date: new Date().toISOString(), level, type: finalJid.endsWith('@lid') ? 'lid' : 'pn' });
  await devDB.write();
  return true;
};

export const removeDeveloper = async (jid) => {
  const idx = devDB.data.developers.findIndex(d => d.jid === jid);
  if (idx === -1) return false;
  devDB.data.developers.splice(idx, 1);
  await devDB.write();
  return true;
};

export const canAddElite = async (sock, jid) => {
  if (isOwner(jid)) return true;
  return await isElite(sock, jid);
};

export const canAddDeveloper = async (sock, jid) => {
  if (isOwner(jid)) return true;
  if (await isElite(sock, jid)) return true;
  return await isDeveloper(sock, jid);
};