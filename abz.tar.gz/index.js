// index.js - Main Entry Point
import { 
  makeWASocket, 
  delay, 
  DisconnectReason, 
  useMultiFileAuthState,
  makeInMemoryStore 
} from '@itsliaaa/baileys';
import { Boom } from '@hapi/boom';
import pino from 'pino';
import { config } from './config.js';
import { loadDatabases, isElite, isDeveloper, isOwner } from './database.js';
import { handler, handleButtonResponse, loadPlugins, plugins } from './handler.js';
import { join } from 'path';
import { watch } from 'chokidar';
import { mkdirSync, existsSync } from 'fs';

// إنشاء المجلدات اللازمة
[config.paths.plugins, config.paths.database, config.paths.temp, config.paths.session].forEach(dir => {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
});

// Logger
const logger = pino({ 
  level: 'silent'
});

// Store للبيانات المؤقتة
const store = makeInMemoryStore({ logger });
store?.readFromFile(join(config.paths.database, 'store.json'));

// حفظ الـ Store كل 3 دقايق
setInterval(() => {
  store?.writeToFile(join(config.paths.database, 'store.json'));
}, 180000);

// متغيرات عامة
let sock = null;
let qrRetry = 0;

const connectToWhatsApp = async () => {
  await loadDatabases();
  
  const { state, saveCreds } = await useMultiFileAuthState(config.paths.session);
  
  sock = makeWASocket({
    logger,
    auth: state,
    printQRInTerminal: !config.pairingCode.enabled,
    browser: [config.credits.botName, 'Chrome', '1.0.0'],
    generateHighQualityLinkPreview: true,
    syncFullHistory: false,
    markOnlineOnConnect: true,
    keepAliveIntervalMs: 30000,
    retryRequestDelayMs: 250,
    maxMsgRetryCount: 5,
    fireInitQueries: true,
    shouldIgnoreJid: jid => jid === 'status@broadcast',
    getMessage: async (key) => {
      const msg = await store.loadMessage(key.remoteJid, key.id);
      return msg?.message || undefined;
    }
  });
  
  store?.bind(sock.ev);
  
  // Pairing Code
  if (config.pairingCode.enabled && !sock.authState.creds.registered) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(config.pairingCode.phoneNumber);
        console.log(`
╭────────────────────────────────────╮
│  🔗 Pairing Code by ${config.credits.developer}          │
│                                    │
│  Code: ${code}                     │
│                                    │
│  افتح واتساب > الأجهزة المرتبطة    │
│  > ربط جهاز > أدخل الكود          │
╰────────────────────────────────────╯
        `);
      } catch (err) {
        console.error('❌ Pairing Code Error:', err.message);
      }
    }, 3000);
  }
  
  // تحميل الـ Plugins
  await loadPlugins(config.paths.plugins);
  
  // Hot Reload للـ Plugins
  const watcher = watch(join(config.paths.plugins, '**/*.js'), {
    ignored: /node_modules/,
    persistent: true
  });
  
  watcher.on('change', async (path) => {
    console.log(`🔄 Plugin changed: ${path}`);
    await loadPlugins(config.paths.plugins);
  });
  
  // معالجة الأحداث
  sock.ev.on('creds.update', saveCreds);
  
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;
    
    if (qr) {
      qrRetry++;
      if (qrRetry > 5) {
        console.log('❌ فشل في الاتصال بعد عدة محاولات');
        process.exit(1);
      }
    }
    
    if (connection === 'connecting') {
      console.log('🔄 جاري الاتصال بـ WhatsApp...');
    }
    
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log('⚠️ Connection closed:', lastDisconnect?.error?.message);
      
      if (shouldReconnect) {
        console.log('🔄 إعادة الاتصال...');
        setTimeout(connectToWhatsApp, 5000);
      }
    }
    
    if (connection === 'open') {
      console.log(`
╭────────────────────────────────────╮
│  ✅ ${config.credits.botName} Connected!        │
│  👤 Developer: ${config.credits.developer}                │
│  📱 Number: ${sock.user.id.split(':')[0]}       │
│  ⚡ Plugins: ${plugins.size} loaded              │
╰────────────────────────────────────╯
      `);
      
      // إرسال رسالة للمالك عند الاتصال
      for (const owner of config.ownerNumber) {
        try {
          await sock.sendMessage(owner, {
            text: `🤖 *${config.credits.botName}* شغال الآن!\n⏰ ${new Date().toLocaleString()}\n🔗 Connected as: ${sock.user.id.split(':')[0]}`
          });
        } catch (e) {
          console.log('⚠️ فشل إرسال رسالة للمالك');
        }
      }
    }
  });
  
  // معالجة الرسائل (السرعة القصوى)
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    
    for (const msg of messages) {
      // معالجة الأزرار بشكل منفصل
      if (msg.message?.buttonsResponseMessage || 
          msg.message?.listResponseMessage ||
          msg.message?.templateButtonReplyMessage) {
        handleButtonResponse(sock, msg);
        continue;
      }
      
      // معالجة الرسائل العادية
      handler(sock, msg, store);
    }
  });
  
  // ✅ معالجة المشاركات في المجموعات (للحماية) - Async مع LID
  sock.ev.on('group-participants.update', async (update) => {
    await handleGroupUpdate(sock, update);
  });
  
  return sock;
};

// حماية المجموعات - Async مع LID support
const handleGroupUpdate = async (sock, update) => {
  try {
    const { id, participants, action } = update;
    
    const groupMetadata = await sock.groupMetadata(id);
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const botAdmin = groupMetadata.participants.find(p => p.id === botNumber)?.admin;
    
    if (!botAdmin) return; // البوت مش أدمن
    
    for (const participant of participants) {
      // ✅ التحقق باستخدام LID support
      const participantIsElite = await isElite(sock, participant);
      const participantIsDev = await isDeveloper(sock, participant);
      const participantIsOwner = isOwner(participant);
      
      if (action === 'remove') {
        const remover = update.author;
        const removerIsOwner = isOwner(remover);
        const removerIsElite = await isElite(sock, remover);
        
        if (participantIsElite || participantIsDev || participantIsOwner) {
          // رجع اللي اتطرد لو نخبة
          await sock.groupParticipantsUpdate(id, [participant], 'add');
          
          // طرد اللي طرده
          if (!removerIsOwner && !removerIsElite) {
            await sock.groupParticipantsUpdate(id, [remover], 'remove');
            await sock.sendMessage(id, {
              text: `🛡️ *حماية النخبة*\nتم منع طرد @${participant.split('@')[0]} وطرد @${remover.split('@')[0]}`,
              mentions: [participant, remover]
            });
          }
        }
      }
      
      if (action === 'promote' || action === 'demote') {
        const actor = update.author;
        const actorIsOwner = isOwner(actor);
        const actorIsElite = await isElite(sock, actor);
        
        if (!actorIsOwner && !actorIsElite) {
          // رجع الوضع كما كان
          const reverseAction = action === 'promote' ? 'demote' : 'promote';
          await sock.groupParticipantsUpdate(id, [participant], reverseAction);
          
          await sock.sendMessage(id, {
            text: `🛡️ *حماية الصلاحيات*\nتم منع ${action === 'promote' ? 'ترقية' : 'تخفيض'} @${participant.split('@')[0]}`,
            mentions: [participant]
          });
        }
      }
    }
  } catch (err) {
    console.error('Group Protection Error:', err.message);
  }
};

// تشغيل البوت
connectToWhatsApp().catch(err => {
  console.error('Fatal Error:', err);
  process.exit(1);
});