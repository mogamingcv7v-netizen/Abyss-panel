// config.js - Global Configuration
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const config = {
  // البيانات الأساسية
  botName: 'Aizen Bot',
  ownerName: 'Aizen',
  ownerNumber: ['201XXXXXXXXX@s.whatsapp.net'], // غير ده برقمك
  
  // الحقوق - تقدر تغيرها من هنا
  credits: {
    developer: 'Aizen',
    botName: 'Aizen Bot',
    version: '1.0.0'
  },
  
  // إعدادات الاتصال
  sessionName: 'aizen-session',
  pairingCode: {
    enabled: true,
    customCode: 'AIZEN', // الكود هيظهر كـ: AIZEN-XXXXXX
    phoneNumber: '201XXXXXXXXX' // رقمك مع كود الدولة بدون +
  },
  
  // إعدادات الرسائل
  messageSettings: {
    ptt: true,        // إرسال الصوت كـ Voice Note
    ptv: false,       // إرسال الفيديو كـ Video Note (دائري)
    viewOnce: false,
    ephemeral: false
  },
  
  // إعدادات الأداء
  performance: {
    maxListeners: 50,
    messageCacheSize: 1000,
    connectionRetry: true
  },
  
  // مسارات الملفات
  paths: {
    plugins: join(__dirname, 'plugins'),
    database: join(__dirname, 'database'),
    temp: join(__dirname, 'temp'),
    session: join(__dirname, 'aizen-session')
  },
  
  // إعدادات النخبة والمطورين
  elite: {
    canAddElite: true,      // النخبة تقدر تضيف نخبة؟
    canAddDeveloper: true,  // النخبة تقدر تضيف مطورين؟
    canUseFileManager: true // النخبة تستخدم مدير الملفات؟
  },
  
  developers: {
    canAddDeveloper: false, // المطورين يضيفوا مطورين؟
    canModifyPlugins: true  // المطورين يعدلوا plugins؟
  }
};

// Helper functions
export const getCredits = () => {
  return `╭───「 *${config.credits.botName}* 」───╮
│ 👤 Developer: ${config.credits.developer}
│ 🤖 Version: ${config.credits.version}
│ ⚡ Powered by @itsliaaa/baileys
╰────────────────────╯`;
};

export default config;
