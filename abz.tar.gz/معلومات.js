// plugins/group.js - إدارة الجروبات (إضافي)
export default {
  name: 'group',
  command: ['groupinfo', 'معلومات'],
  description: 'معلومات الجروب',
  group: true, // للجروبات فقط
  
  async execute({ sock, m, isGroup }) {
    if (!isGroup) return; // احتياطي
    
    const metadata = await sock.groupMetadata(m.chat);
    const text = `
📊 *معلومات الجروب*

👥 *الاسم:* ${metadata.subject}
📝 *الوصف:* ${metadata.desc || 'لا يوجد'}
👤 *الأعضاء:* ${metadata.participants.length}
🕐 *تاريخ الإنشاء:* ${new Date(metadata.creation * 1000).toLocaleDateString()}
    `;
    
    return m.reply(text);
  }
};