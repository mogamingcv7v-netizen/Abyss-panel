require('dotenv').config();
const express     = require('express');
const cors        = require('cors');
const helmet      = require('helmet');
const rateLimit   = require('express-rate-limit');
const path        = require('path');

const app = express();

// ── Security ──────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET','POST','PUT','PATCH','DELETE'],
  allowedHeaders: ['Content-Type','Authorization','X-API-Key'],
}));

// ── Rate limiting ─────────────────────────────────
app.use('/api/auth/login', rateLimit({
  windowMs: 15 * 60 * 1000, max: 20,
  message: { error: 'Too many login attempts. Try again in 15 minutes.' }
}));
// Public API v1 — stricter per-minute limit (bots can be chatty)
app.use('/api/v1/', rateLimit({
  windowMs: 60 * 1000, max: 120,
  message: { error: 'API rate limit exceeded. Max 120 req/min.' }
}));
app.use('/api/', rateLimit({
  windowMs: 60 * 1000, max: 500,
  message: { error: 'Too many requests.' }
}));

// ── Body parsing ──────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── API Routes ────────────────────────────────────
app.use('/api/auth',    require('./routes/auth'));
app.use('/api/users',   require('./routes/users'));
app.use('/api/ranges',  require('./routes/ranges'));
app.use('/api/numbers', require('./routes/numbers'));
app.use('/api/traffic', require('./routes/traffic'));
app.use('/api/targets', require('./routes/targets'));
app.use('/api/admin',   require('./routes/admin'));
app.use('/api/apikeys', require('./routes/apikeys'));  // Key management (JWT auth)
app.use('/api/v1',      require('./routes/v1'));        // Public API (API Key auth)

// ── Health check ──────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ── Serve frontend ────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Error handler ─────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[Server Error]', err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = parseInt(process.env.PORT) || 3000;
app.listen(PORT, () => {
  console.log(`ABYSS PANEL running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});
