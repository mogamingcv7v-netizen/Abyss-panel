# ABYSS PANEL — Public API v1 Documentation

Base URL: `https://your-domain.com/api/v1`

---

## Authentication

كل request لازم يحتوي على API Key بإحدى الطريقتين:

```
# Header (مفضل)
X-API-Key: ABYSS_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# Query param (للبوتات البسيطة)
GET /api/v1/numbers?api_key=ABYSS_XXXX...
```

---

## إنشاء API Key (من الداشبورد)

```http
POST /api/apikeys
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json

{
  "label": "My Telegram Bot",
  "scope": "read",          // read | write | full
  "expires_at": null        // أو "2026-12-31T00:00:00Z"
}
```

**Response:**
```json
{
  "data": {
    "id": 1,
    "key_value": "ABYSS_A1B2C3D4E5F6...",
    "label": "My Telegram Bot",
    "scope": "read",
    "active": true,
    "created_at": "2026-03-26T00:00:00Z"
  },
  "warning": "Save this key — it will not be shown again in full"
}
```

> ⚠️ الـ key بيتعرض مرة واحدة بس عند الإنشاء!

---

## Scopes

| Scope   | يسمح بـ                                    |
|---------|---------------------------------------------|
| `read`  | GET فقط — عرض numbers و SMS و stats         |
| `write` | read + POST /sms (بوتات ترفع SMS)           |
| `full`  | كل شيء (للـ superadmin والـ dev فقط)        |

---

## Endpoints

### GET /api/v1/me
معلومات الـ key والحساب المرتبط به.

```bash
curl -H "X-API-Key: ABYSS_XXX" https://your-domain.com/api/v1/me
```

**Response:**
```json
{
  "api_key": {
    "label": "My Bot",
    "scope": "read"
  },
  "account": {
    "id": 5,
    "username": "john",
    "role": "user",
    "country": "Egypt"
  },
  "numbers_count": 12
}
```

---

### GET /api/v1/numbers
كل الأرقام المخصصة للحساب.

**Query params:**
| Param     | مثال         | وصف                    |
|-----------|--------------|------------------------|
| `country` | `Egypt`      | فلتر بالدولة           |
| `q`       | `2012`       | بحث في الرقم           |
| `page`    | `1`          | رقم الصفحة             |
| `per`     | `50`         | عدد النتائج (max 100)  |

```bash
curl -H "X-API-Key: ABYSS_XXX" \
  "https://your-domain.com/api/v1/numbers?country=Egypt&page=1&per=20"
```

**Response:**
```json
{
  "data": [
    {
      "number": "201012345678",
      "prefix": "20",
      "country": "Egypt",
      "range_name": "Vodafone EG Range 1",
      "payout": "0.0500",
      "payterm": "Monthly15",
      "total_sms": 1234,
      "total_payout": "61.70",
      "last_activity": "2026-03-25T18:30:00Z"
    }
  ],
  "total": 12,
  "page": 1,
  "per": 20
}
```

---

### GET /api/v1/numbers/:number
تفاصيل رقم واحد.

```bash
curl -H "X-API-Key: ABYSS_XXX" \
  https://your-domain.com/api/v1/numbers/201012345678
```

---

### GET /api/v1/sms
سجلات الـ SMS مع فلاتر.

**Query params:**
| Param    | مثال         | وصف                    |
|----------|--------------|------------------------|
| `number` | `201012345678` | فلتر برقم معين       |
| `cli`    | `Vodafone`   | فلتر بالمرسِل          |
| `from`   | `2026-03-01` | من تاريخ               |
| `to`     | `2026-03-26` | إلى تاريخ              |
| `page`   | `1`          |                        |
| `per`    | `25`         | max 100                |

```bash
curl -H "X-API-Key: ABYSS_XXX" \
  "https://your-domain.com/api/v1/sms?number=201012345678&from=2026-03-01"
```

**Response:**
```json
{
  "data": [
    {
      "id": 99,
      "number": "201012345678",
      "range_name": "Vodafone EG Range 1",
      "cli": "Vodafone",
      "sms": 150,
      "currency": "USD",
      "payout": "7.50",
      "recorded_at": "2026-03-26T10:00:00Z"
    }
  ],
  "total": 45,
  "summary": {
    "total_sms": 6750,
    "total_payout": "337.50"
  },
  "page": 1,
  "per": 25
}
```

---

### GET /api/v1/sms/latest
آخر N سجلات SMS.

```bash
# آخر 10 بشكل عام
curl -H "X-API-Key: ABYSS_XXX" https://your-domain.com/api/v1/sms/latest

# آخر 5 لرقم معين
curl -H "X-API-Key: ABYSS_XXX" \
  "https://your-domain.com/api/v1/sms/latest?number=201012345678&limit=5"
```

---

### POST /api/v1/sms *(scope: write أو full)*
بوتات الـ SMS ترفع بيانات traffic.

```bash
curl -X POST \
  -H "X-API-Key: ABYSS_XXX" \
  -H "Content-Type: application/json" \
  -d '{
    "number": "201012345678",
    "cli": "Vodafone",
    "sms": 200,
    "currency": "USD",
    "payout": 10.00
  }' \
  https://your-domain.com/api/v1/sms
```

**Body params:**
| Field        | نوع    | مطلوب | وصف                              |
|--------------|--------|-------|----------------------------------|
| `number`     | string | ✅    | الرقم (لازم يكون مخصص ليك)       |
| `sms`        | int    | ✅    | عدد الـ SMS                      |
| `cli`        | string | ❌    | اسم المشغل / المرسِل             |
| `currency`   | string | ❌    | العملة (default: USD)            |
| `payout`     | float  | ❌    | لو مش موجود بيتحسب تلقائي        |
| `recorded_at`| string | ❌    | ISO date (default: now)          |

---

### GET /api/v1/stats
إحصائيات سريعة.

```bash
curl -H "X-API-Key: ABYSS_XXX" https://your-domain.com/api/v1/stats
```

**Response:**
```json
{
  "numbers": 12,
  "today_sms": 450,
  "today_payout": 22.5,
  "week_sms": 2100,
  "month_sms": 8400,
  "month_payout": 420.0,
  "all_sms": 54000,
  "all_payout": 2700.0,
  "sessions": 1200
}
```

---

## Error Codes

| Code | معنى                            |
|------|---------------------------------|
| 401  | API key مش موجود أو غلط         |
| 403  | Key موقف / منتهي / scope ناقص  |
| 404  | الرقم مش موجود أو مش بتاعك      |
| 429  | Rate limit (120 req/min)        |
| 500  | Server error                    |

---

## إدارة الـ Keys (Dashboard)

```http
# عرض keys بتاعتك
GET /api/apikeys
Authorization: Bearer <JWT>

# إيقاف key
PATCH /api/apikeys/1
Authorization: Bearer <JWT>
{ "active": false }

# تغيير الاسم
PATCH /api/apikeys/1
Authorization: Bearer <JWT>
{ "label": "New Name" }

# حذف key
DELETE /api/apikeys/1
Authorization: Bearer <JWT>

# عرض كل الـ keys (admin/dev فقط)
GET /api/apikeys/all
Authorization: Bearer <JWT>
```

---

## مثال — بوت تيليجرام (Python)

```python
import requests

API_KEY = "ABYSS_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
BASE    = "https://your-domain.com/api/v1"
HEADERS = {"X-API-Key": API_KEY}

def get_my_numbers():
    r = requests.get(f"{BASE}/numbers", headers=HEADERS)
    return r.json()["data"]

def get_latest_sms(number=None, limit=10):
    params = {"limit": limit}
    if number:
        params["number"] = number
    r = requests.get(f"{BASE}/sms/latest", headers=HEADERS, params=params)
    return r.json()["data"]

def get_stats():
    r = requests.get(f"{BASE}/stats", headers=HEADERS)
    return r.json()

# مثال استخدام
numbers = get_my_numbers()
print(f"عندك {len(numbers)} رقم")

latest = get_latest_sms(limit=5)
for sms in latest:
    print(f"{sms['number']} — {sms['sms']} SMS — {sms['recorded_at']}")
```

---

## Migration

```bash
node db/migrate_apikeys.js
```

---

## ملاحظات

- الـ key بيتعرض **مرة واحدة** عند الإنشاء فقط
- كل user عنده حد أقصى **10 keys**
- الـ rate limit للـ API: **120 request/minute**
- الـ key preview في الداشبورد بيعرض أول 12 حرف فقط
