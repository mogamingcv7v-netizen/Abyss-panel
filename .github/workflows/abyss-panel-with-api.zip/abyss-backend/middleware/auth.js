const jwt = require('jsonwebtoken');
const pool = require('../config/db');

// Verify JWT token
async function auth(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // Fetch fresh user from DB
    const { rows } = await pool.query(
      `SELECT id, username, role, name, email, country, company, skype, contact, address, active, created_at, last_login, login_count
       FROM accounts WHERE id=$1`, [decoded.id]
    );
    if (!rows.length || !rows[0].active) {
      return res.status(401).json({ error: 'Account not found or disabled' });
    }
    req.user = rows[0];
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Require dev or superadmin role
function requireDev(req, res, next) {
  if (req.user.role !== 'dev' && req.user.role !== 'superadmin') {
    return res.status(403).json({ error: 'Dev/Admin access required' });
  }
  next();
}

// Require superadmin role
function requireAdmin(req, res, next) {
  if (req.user.role !== 'superadmin') {
    return res.status(403).json({ error: 'Superadmin access required' });
  }
  next();
}

module.exports = { auth, requireDev, requireAdmin };
