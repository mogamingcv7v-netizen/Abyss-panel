const pool = require('../config/db');

/**
 * API Key Authentication Middleware
 * Accepts key via:
 *   - Header:  X-API-Key: ABYSS_xxxxx
 *   - Query:   ?api_key=ABYSS_xxxxx
 */
async function apiKeyAuth(req, res, next) {
  const key = req.headers['x-api-key'] || req.query.api_key;

  if (!key) {
    return res.status(401).json({
      error: 'API key required',
      hint: 'Pass via X-API-Key header or ?api_key= query param'
    });
  }

  try {
    const { rows } = await pool.query(
      `SELECT k.*, a.id AS account_id, a.username, a.role, a.active AS account_active
       FROM api_keys k
       JOIN accounts a ON a.id = k.user_id
       WHERE k.key_value = $1`,
      [key]
    );

    if (!rows.length) {
      return res.status(401).json({ error: 'Invalid API key' });
    }

    const keyRow = rows[0];

    if (!keyRow.active) {
      return res.status(403).json({ error: 'API key is disabled' });
    }
    if (!keyRow.account_active) {
      return res.status(403).json({ error: 'Account is disabled' });
    }
    if (keyRow.expires_at && new Date(keyRow.expires_at) < new Date()) {
      return res.status(403).json({ error: 'API key has expired' });
    }

    // Update last_used + request count
    await pool.query(
      `UPDATE api_keys SET last_used = NOW(), request_count = request_count + 1 WHERE id = $1`,
      [keyRow.id]
    );

    // Attach to request
    req.apiKey = {
      id:        keyRow.id,
      label:     keyRow.label,
      scope:     keyRow.scope,  // 'read' | 'write' | 'full'
      user_id:   keyRow.account_id,
      username:  keyRow.username,
      role:      keyRow.role,
    };

    next();
  } catch (err) {
    console.error('[apiKeyAuth]', err.message);
    res.status(500).json({ error: 'Auth error' });
  }
}

// Require specific scope
function requireScope(...scopes) {
  return (req, res, next) => {
    if (!scopes.includes(req.apiKey.scope) && req.apiKey.scope !== 'full') {
      return res.status(403).json({
        error: `This endpoint requires scope: ${scopes.join(' or ')}`,
        your_scope: req.apiKey.scope
      });
    }
    next();
  };
}

module.exports = { apiKeyAuth, requireScope };
