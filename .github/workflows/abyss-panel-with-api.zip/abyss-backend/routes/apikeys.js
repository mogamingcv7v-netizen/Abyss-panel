/**
 * API Keys Management — Dashboard Routes
 * Base: /api/apikeys
 * Auth: JWT (existing dashboard auth)
 *
 *   POST   /api/apikeys          — create a new key
 *   GET    /api/apikeys          — list my keys
 *   PATCH  /api/apikeys/:id      — toggle active / rename
 *   DELETE /api/apikeys/:id      — delete key
 *
 * Admin/Dev extras:
 *   GET    /api/apikeys/all      — all keys across all users
 */

const router = require('express').Router();
const crypto = require('crypto');
const pool   = require('../config/db');
const { auth, requireDev } = require('../middleware/auth');

// Generate a secure key: ABYSS_<32 random hex chars>
function generateKey() {
  return 'ABYSS_' + crypto.randomBytes(20).toString('hex').toUpperCase();
}

// ─── POST /api/apikeys ───────────────────────────────────────────────────────
router.post('/', auth, async (req, res) => {
  const { label, scope = 'read', expires_at } = req.body;

  // Only admin/dev can create 'write' or 'full' scoped keys for others
  const validScopes = ['read', 'write', 'full'];
  if (!validScopes.includes(scope)) {
    return res.status(400).json({ error: `scope must be: ${validScopes.join(', ')}` });
  }

  // Users can only create 'read' or 'write' keys (not 'full')
  if (req.user.role === 'user' && scope === 'full') {
    return res.status(403).json({ error: 'Users cannot create full-scope keys' });
  }

  // Max 10 keys per user
  const countRes = await pool.query(
    `SELECT COUNT(*) FROM api_keys WHERE user_id = $1`, [req.user.id]
  );
  if (parseInt(countRes.rows[0].count) >= 10) {
    return res.status(400).json({ error: 'Maximum 10 API keys per account' });
  }

  try {
    const key = generateKey();
    const { rows } = await pool.query(
      `INSERT INTO api_keys(user_id, key_value, label, scope, expires_at)
       VALUES($1,$2,$3,$4,$5) RETURNING *`,
      [req.user.id, key, label || 'My Key', scope, expires_at || null]
    );
    // Return full key only on creation — never shown again
    res.status(201).json({
      data: rows[0],
      warning: 'Save this key — it will not be shown again in full'
    });
  } catch (err) {
    console.error('[apikeys POST]', err);
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/apikeys ────────────────────────────────────────────────────────
router.get('/', auth, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, label, scope,
              LEFT(key_value, 12) || '••••••••••••••••••••' AS key_preview,
              active, last_used, request_count, expires_at, created_at
       FROM api_keys
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/apikeys/all — admin/dev only ───────────────────────────────────
router.get('/all', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT k.id, k.label, k.scope,
              LEFT(k.key_value, 12) || '••••••••••••••••••••' AS key_preview,
              k.active, k.last_used, k.request_count, k.expires_at, k.created_at,
              a.username, a.role
       FROM api_keys k
       JOIN accounts a ON a.id = k.user_id
       ORDER BY k.created_at DESC`
    );
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── PATCH /api/apikeys/:id ──────────────────────────────────────────────────
router.patch('/:id', auth, async (req, res) => {
  const { label, active, expires_at } = req.body;
  const id = parseInt(req.params.id);
  try {
    // Verify ownership (admin can edit any)
    const existing = await pool.query(
      `SELECT * FROM api_keys WHERE id = $1`, [id]
    );
    if (!existing.rows.length) return res.status(404).json({ error: 'Key not found' });
    if (existing.rows[0].user_id !== req.user.id && req.user.role === 'user') {
      return res.status(403).json({ error: 'Not your key' });
    }

    const fields = [];
    const params = [];
    let pi = 1;

    if (label     !== undefined) { fields.push(`label=$${pi++}`);      params.push(label); }
    if (active    !== undefined) { fields.push(`active=$${pi++}`);     params.push(active); }
    if (expires_at !== undefined){ fields.push(`expires_at=$${pi++}`); params.push(expires_at || null); }

    if (!fields.length) return res.status(400).json({ error: 'Nothing to update' });

    params.push(id);
    const { rows } = await pool.query(
      `UPDATE api_keys SET ${fields.join(',')} WHERE id=$${pi}
       RETURNING id, label, scope,
         LEFT(key_value,12) || '••••••••••••••••••••' AS key_preview,
         active, last_used, request_count, expires_at, created_at`,
      params
    );
    res.json({ data: rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── DELETE /api/apikeys/:id ─────────────────────────────────────────────────
router.delete('/:id', auth, async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const existing = await pool.query(
      `SELECT user_id FROM api_keys WHERE id = $1`, [id]
    );
    if (!existing.rows.length) return res.status(404).json({ error: 'Key not found' });
    if (existing.rows[0].user_id !== req.user.id && req.user.role === 'user') {
      return res.status(403).json({ error: 'Not your key' });
    }
    await pool.query(`DELETE FROM api_keys WHERE id = $1`, [id]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
