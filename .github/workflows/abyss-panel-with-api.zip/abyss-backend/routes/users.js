const router = require('express').Router();
const bcrypt = require('bcryptjs');
const pool   = require('../config/db');
const { auth, requireDev, requireAdmin } = require('../middleware/auth');

// GET /api/users — list all accounts
router.get('/', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.id,a.username,a.role,a.name,a.email,a.country,a.company,a.active,
              a.created_at,a.last_login,a.login_count,
              COUNT(n.id) AS num_count
       FROM accounts a
       LEFT JOIN numbers n ON n.assigned_to = a.id
       GROUP BY a.id
       ORDER BY a.id`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// POST /api/users — create account
router.post('/', auth, requireDev, async (req, res) => {
  const { username, password, role, name, email, country, company } = req.body;
  if (!username || !password || !name) return res.status(400).json({ error: 'Missing required fields' });
  if (password.length < 6) return res.status(400).json({ error: 'Password too short' });
  // Only superadmin can create superadmin/dev
  if ((role === 'superadmin' || role === 'dev') && req.user.role !== 'superadmin')
    return res.status(403).json({ error: 'Only superadmin can create dev/superadmin accounts' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const { rows } = await pool.query(
      `INSERT INTO accounts(username,password,role,name,email,country,company,active)
       VALUES($1,$2,$3,$4,$5,$6,$7,true) RETURNING id,username,role,name,email,country,active,created_at`,
      [username, hash, role||'user', name, email||null, country||null, company||null]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ error: 'Username already taken' });
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/users/:id — edit account
router.put('/:id', auth, requireDev, async (req, res) => {
  const { username, password, role, name, email, country, company, skype, contact, address } = req.body;
  const id = parseInt(req.params.id);
  try {
    if (password) {
      const hash = await bcrypt.hash(password, 12);
      await pool.query(`UPDATE accounts SET password=$1 WHERE id=$2`, [hash, id]);
    }
    const { rows } = await pool.query(
      `UPDATE accounts SET username=$1,role=$2,name=$3,email=$4,country=$5,company=$6,skype=$7,contact=$8,address=$9
       WHERE id=$10 RETURNING id,username,role,name,email,country,active,created_at`,
      [username, role, name, email||null, country||null, company||null, skype||null, contact||null, address||null, id]
    );
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// PATCH /api/users/:id/toggle — enable/disable
router.patch('/:id/toggle', auth, requireDev, async (req, res) => {
  const id = parseInt(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'Cannot disable yourself' });
  try {
    const { rows } = await pool.query(
      `UPDATE accounts SET active = NOT active WHERE id=$1 RETURNING id,username,active`, [id]
    );
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// DELETE /api/users/:id — delete user, return numbers to stock
router.delete('/:id', auth, requireAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
  try {
    await pool.query(
      `UPDATE numbers SET assigned_to=NULL,assigned_date=NULL,payterm=NULL,payout=NULL,sd_limit=0,sw_limit=0 WHERE assigned_to=$1`, [id]
    );
    await pool.query(`DELETE FROM accounts WHERE id=$1`, [id]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/users/stats — per-user SMS stats
router.get('/stats', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.id, a.username, a.name,
              COUNT(DISTINCT n.id)  AS nums,
              COALESCE(SUM(t.sms),0)    AS total_sms,
              COALESCE(SUM(t.payout),0) AS total_payout,
              COUNT(t.id)           AS sessions,
              MAX(t.recorded_at)    AS last_activity
       FROM accounts a
       LEFT JOIN numbers n ON n.assigned_to = a.id
       LEFT JOIN traffic t ON t.user_id = a.id
       WHERE a.role = 'user'
       GROUP BY a.id
       ORDER BY total_sms DESC`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

module.exports = router;
