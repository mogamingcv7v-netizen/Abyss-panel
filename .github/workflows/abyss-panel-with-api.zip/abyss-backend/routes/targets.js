const router = require('express').Router();
const pool   = require('../config/db');
const { auth, requireDev } = require('../middleware/auth');

// GET /api/targets — all user targets with current progress
router.get('/', auth, requireDev, async (req, res) => {
  try {
    const today = new Date().toISOString().slice(0,10);
    const month = new Date(Date.now() - 30*86400000).toISOString().slice(0,10);
    const { rows } = await pool.query(
      `SELECT a.id, a.username,
        COALESCE(tg_d.value,0) AS daily_target,
        COALESCE(tg_m.value,0) AS monthly_target,
        COALESCE(SUM(t.sms) FILTER(WHERE t.recorded_at::date = $1::date),0) AS today_sms,
        COALESCE(SUM(t.sms) FILTER(WHERE t.recorded_at >= $2),0) AS month_sms
       FROM accounts a
       LEFT JOIN targets tg_d ON tg_d.user_id = a.id AND tg_d.type = 'daily'
       LEFT JOIN targets tg_m ON tg_m.user_id = a.id AND tg_m.type = 'monthly'
       LEFT JOIN traffic t    ON t.user_id = a.id
       WHERE a.role = 'user'
       GROUP BY a.id, a.username, tg_d.value, tg_m.value
       ORDER BY a.username`,
      [today, month]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/targets/me — current user's targets + progress
router.get('/me', auth, async (req, res) => {
  const uid = req.user.id;
  const today = new Date().toISOString().slice(0,10);
  const month = new Date(Date.now() - 30*86400000).toISOString().slice(0,10);
  try {
    const [tgts, today_r, month_r] = await Promise.all([
      pool.query(`SELECT type, value FROM targets WHERE user_id=$1`, [uid]),
      pool.query(`SELECT COALESCE(SUM(sms),0) AS sms FROM traffic WHERE user_id=$1 AND recorded_at::date=$2::date`, [uid, today]),
      pool.query(`SELECT COALESCE(SUM(sms),0) AS sms FROM traffic WHERE user_id=$1 AND recorded_at>=$2`, [uid, month]),
    ]);
    const daily_target   = tgts.rows.find(r=>r.type==='daily')?.value   || 0;
    const monthly_target = tgts.rows.find(r=>r.type==='monthly')?.value || 0;
    const today_sms  = parseInt(today_r.rows[0].sms);
    const month_sms  = parseInt(month_r.rows[0].sms);
    res.json({ daily_target, monthly_target, today_sms, month_sms,
      daily_pct:   daily_target   ? Math.min(100, Math.round(today_sms/daily_target*100))   : 0,
      monthly_pct: monthly_target ? Math.min(100, Math.round(month_sms/monthly_target*100)) : 0,
    });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// PUT /api/targets/:userId/:type — set target
router.put('/:userId/:type', auth, requireDev, async (req, res) => {
  const { userId, type } = req.params;
  const { value } = req.body;
  if (!['daily','monthly'].includes(type)) return res.status(400).json({ error: 'type must be daily or monthly' });
  try {
    await pool.query(
      `INSERT INTO targets(user_id,type,value,updated_at) VALUES($1,$2,$3,NOW())
       ON CONFLICT(user_id,type) DO UPDATE SET value=$3, updated_at=NOW()`,
      [parseInt(userId), type, parseInt(value)||0]
    );
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

module.exports = router;
