/**
 * ABYSS PANEL — Public API v1
 * Base: /api/v1
 *
 * Auth: X-API-Key header or ?api_key= query param
 *
 * Endpoints:
 *   GET  /api/v1/me               — key info + account summary
 *   GET  /api/v1/numbers          — my assigned numbers
 *   GET  /api/v1/numbers/:number  — single number details
 *   GET  /api/v1/sms              — SMS/traffic records (filterable)
 *   GET  /api/v1/sms/latest       — latest N SMS records
 *   POST /api/v1/sms              — push a traffic record  [scope: write|full]
 *   GET  /api/v1/stats            — quick stats for the key's user
 */

const router = require('express').Router();
const pool   = require('../config/db');
const { apiKeyAuth, requireScope } = require('../middleware/apiKeyAuth');

// Apply API key auth to all v1 routes
router.use(apiKeyAuth);

// ─── GET /api/v1/me ──────────────────────────────────────────────────────────
router.get('/me', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, username, role, name, email, country, company, skype, contact,
              created_at, last_login, login_count
       FROM accounts WHERE id = $1`,
      [req.apiKey.user_id]
    );

    const numberCount = await pool.query(
      `SELECT COUNT(*) FROM numbers WHERE assigned_to = $1 AND active = true`,
      [req.apiKey.user_id]
    );

    res.json({
      api_key: {
        label:         req.apiKey.label,
        scope:         req.apiKey.scope,
      },
      account: rows[0],
      numbers_count: parseInt(numberCount.rows[0].count),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/v1/numbers ─────────────────────────────────────────────────────
router.get('/numbers', async (req, res) => {
  const { country, q, page = 1, per = 50 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(per);
  try {
    let where  = [`n.assigned_to = $1`, `n.active = true`];
    let params = [req.apiKey.user_id];
    let pi     = 2;

    if (country) { where.push(`n.country ILIKE $${pi++}`); params.push(`%${country}%`); }
    if (q)       { where.push(`n.number ILIKE $${pi++}`);  params.push(`%${q}%`); }

    const wc = 'WHERE ' + where.join(' AND ');

    const { rows } = await pool.query(
      `SELECT n.number, n.prefix, n.country, n.range_name,
              n.payout, n.payterm, n.sd_limit, n.sw_limit, n.assigned_date,
              COALESCE(SUM(t.sms),0)    AS total_sms,
              COALESCE(SUM(t.payout),0) AS total_payout,
              MAX(t.recorded_at)        AS last_activity
       FROM numbers n
       LEFT JOIN traffic t ON t.number_id = n.id
       ${wc}
       GROUP BY n.id
       ORDER BY n.id
       LIMIT $${pi} OFFSET $${pi+1}`,
      [...params, parseInt(per), offset]
    );

    const count = await pool.query(
      `SELECT COUNT(*) FROM numbers n ${wc}`, params
    );

    res.json({
      data:  rows,
      total: parseInt(count.rows[0].count),
      page:  parseInt(page),
      per:   parseInt(per),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/v1/numbers/:number ─────────────────────────────────────────────
router.get('/numbers/:number', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT n.number, n.prefix, n.country, n.range_name,
              n.payout, n.payterm, n.sd_limit, n.sw_limit, n.assigned_date,
              COALESCE(SUM(t.sms),0)    AS total_sms,
              COALESCE(SUM(t.payout),0) AS total_payout,
              MAX(t.recorded_at)        AS last_activity
       FROM numbers n
       LEFT JOIN traffic t ON t.number_id = n.id
       WHERE n.number = $1 AND n.assigned_to = $2 AND n.active = true
       GROUP BY n.id`,
      [req.params.number, req.apiKey.user_id]
    );

    if (!rows.length) {
      return res.status(404).json({ error: 'Number not found or not assigned to you' });
    }
    res.json({ data: rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/v1/sms ─────────────────────────────────────────────────────────
router.get('/sms', async (req, res) => {
  const { number, from, to, cli, page = 1, per = 25 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(per);
  try {
    let where  = [`t.user_id = $1`];
    let params = [req.apiKey.user_id];
    let pi     = 2;

    if (number) { where.push(`t.number = $${pi++}`);         params.push(number); }
    if (cli)    { where.push(`t.cli ILIKE $${pi++}`);        params.push(`%${cli}%`); }
    if (from)   { where.push(`t.recorded_at >= $${pi++}`);   params.push(from + ' 00:00:00'); }
    if (to)     { where.push(`t.recorded_at <= $${pi++}`);   params.push(to   + ' 23:59:59'); }

    const wc = 'WHERE ' + where.join(' AND ');

    const { rows } = await pool.query(
      `SELECT t.id, t.number, t.range_name, t.cli, t.sms,
              t.currency, t.payout, t.recorded_at
       FROM traffic t
       ${wc}
       ORDER BY t.recorded_at DESC
       LIMIT $${pi} OFFSET $${pi+1}`,
      [...params, parseInt(per), offset]
    );

    const totals = await pool.query(
      `SELECT COUNT(*) AS records,
              COALESCE(SUM(sms),0)    AS total_sms,
              COALESCE(SUM(payout),0) AS total_payout
       FROM traffic t ${wc}`, params
    );

    res.json({
      data:    rows,
      total:   parseInt(totals.rows[0].records),
      summary: {
        total_sms:    parseInt(totals.rows[0].total_sms),
        total_payout: parseFloat(totals.rows[0].total_payout),
      },
      page: parseInt(page),
      per:  parseInt(per),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/v1/sms/latest ──────────────────────────────────────────────────
router.get('/sms/latest', async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 10, 100);
  const { number } = req.query;
  try {
    let where  = [`t.user_id = $1`];
    let params = [req.apiKey.user_id];

    if (number) { where.push(`t.number = $2`); params.push(number); }

    const { rows } = await pool.query(
      `SELECT t.id, t.number, t.range_name, t.cli, t.sms,
              t.currency, t.payout, t.recorded_at
       FROM traffic t
       WHERE ${where.join(' AND ')}
       ORDER BY t.recorded_at DESC
       LIMIT $${params.length + 1}`,
      [...params, limit]
    );

    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── POST /api/v1/sms ────────────────────────────────────────────────────────
// Bots use this to push SMS records into the panel
router.post('/sms', requireScope('write'), async (req, res) => {
  const { number, cli, sms, currency, payout, ip, recorded_at } = req.body;

  if (!number || !sms) {
    return res.status(400).json({ error: '`number` and `sms` are required' });
  }

  try {
    // Verify the number belongs to this user
    const numRes = await pool.query(
      `SELECT * FROM numbers WHERE number = $1 AND assigned_to = $2 AND active = true`,
      [number, req.apiKey.user_id]
    );

    if (!numRes.rows.length) {
      return res.status(404).json({ error: 'Number not found or not assigned to you' });
    }

    const n = numRes.rows[0];
    const smsCount = parseInt(sms);
    const payoutVal = payout !== undefined
      ? parseFloat(payout)
      : smsCount * (n.payout || 0);

    const { rows } = await pool.query(
      `INSERT INTO traffic(user_id, number_id, number, range_name, cli, sms, currency, payout, ip, recorded_at)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [
        req.apiKey.user_id, n.id, n.number, n.range_name,
        cli || 'XXXXX', smsCount, currency || 'USD', payoutVal,
        ip || req.ip,
        recorded_at ? new Date(recorded_at) : new Date()
      ]
    );

    res.status(201).json({ data: rows[0] });
  } catch (err) {
    console.error('[v1/sms POST]', err);
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/v1/stats ───────────────────────────────────────────────────────
router.get('/stats', async (req, res) => {
  const uid = req.apiKey.user_id;
  try {
    const today = new Date().toISOString().slice(0, 10);
    const week  = new Date(Date.now() - 7  * 86400000).toISOString().slice(0, 10);
    const month = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);

    const [todayR, weekR, monthR, allR, numbersR] = await Promise.all([
      pool.query(
        `SELECT COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout
         FROM traffic WHERE user_id=$1 AND recorded_at::date=$2`,
        [uid, today]
      ),
      pool.query(
        `SELECT COALESCE(SUM(sms),0) AS sms FROM traffic WHERE user_id=$1 AND recorded_at >= $2`,
        [uid, week]
      ),
      pool.query(
        `SELECT COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout
         FROM traffic WHERE user_id=$1 AND recorded_at >= $2`,
        [uid, month]
      ),
      pool.query(
        `SELECT COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout, COUNT(*) AS sessions
         FROM traffic WHERE user_id=$1`,
        [uid]
      ),
      pool.query(
        `SELECT COUNT(*) FROM numbers WHERE assigned_to=$1 AND active=true`,
        [uid]
      ),
    ]);

    res.json({
      numbers:      parseInt(numbersR.rows[0].count),
      today_sms:    parseInt(todayR.rows[0].sms),
      today_payout: parseFloat(todayR.rows[0].payout),
      week_sms:     parseInt(weekR.rows[0].sms),
      month_sms:    parseInt(monthR.rows[0].sms),
      month_payout: parseFloat(monthR.rows[0].payout),
      all_sms:      parseInt(allR.rows[0].sms),
      all_payout:   parseFloat(allR.rows[0].payout),
      sessions:     parseInt(allR.rows[0].sessions),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
