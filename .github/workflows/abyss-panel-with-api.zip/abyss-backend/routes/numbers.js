const router = require('express').Router();
const pool   = require('../config/db');
const { auth, requireDev, requireAdmin } = require('../middleware/auth');

// GET /api/numbers — all numbers (admin/dev) or my numbers (user)
router.get('/', auth, async (req, res) => {
  const { range_id, status, q, page = 1, per = 30 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(per);
  try {
    if (req.user.role === 'user') {
      // User only sees their own numbers
      const { rows } = await pool.query(
        `SELECT n.*,
                COALESCE(SUM(t.sms),0)    AS total_sms,
                COALESCE(SUM(t.payout),0) AS total_payout,
                MAX(t.recorded_at)        AS last_activity
         FROM numbers n
         LEFT JOIN traffic t ON t.number_id = n.id
         WHERE n.assigned_to = $1 AND n.active = true
         GROUP BY n.id
         ORDER BY n.id
         LIMIT $2 OFFSET $3`,
        [req.user.id, parseInt(per), offset]
      );
      const total = await pool.query(`SELECT COUNT(*) FROM numbers WHERE assigned_to=$1`, [req.user.id]);
      return res.json({ rows, total: parseInt(total.rows[0].count) });
    }

    // Dev/admin: full view with filters
    let where = [];
    let params = [];
    let pi = 1;
    if (range_id) { where.push(`n.range_id=$${pi++}`); params.push(parseInt(range_id)); }
    if (status === 'stock')    { where.push(`n.assigned_to IS NULL`); }
    if (status === 'assigned') { where.push(`n.assigned_to IS NOT NULL`); }
    if (q) {
      where.push(`(n.number ILIKE $${pi} OR a.username ILIKE $${pi})`);
      params.push(`%${q}%`); pi++;
    }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';

    const { rows } = await pool.query(
      `SELECT n.*, a.username AS owner_username,
              COALESCE(SUM(t.sms),0)    AS total_sms,
              COALESCE(SUM(t.payout),0) AS total_payout
       FROM numbers n
       LEFT JOIN accounts a ON a.id = n.assigned_to
       LEFT JOIN traffic t ON t.number_id = n.id
       ${whereClause}
       GROUP BY n.id, a.username
       ORDER BY n.id
       LIMIT $${pi} OFFSET $${pi+1}`,
      [...params, parseInt(per), offset]
    );
    const count = await pool.query(
      `SELECT COUNT(*) FROM numbers n LEFT JOIN accounts a ON a.id=n.assigned_to ${whereClause}`, params
    );
    res.json({ rows, total: parseInt(count.rows[0].count) });
  } catch (err) { console.error('[numbers]', err); res.status(500).json({ error: err.message }) }
});

// POST /api/numbers/allocate — assign numbers from stock to user
router.post('/allocate', auth, requireDev, async (req, res) => {
  const { range_id, user_id, qty, payout, payterm, sd_limit, sw_limit } = req.body;
  if (!range_id || !user_id || !qty) return res.status(400).json({ error: 'range_id, user_id, qty required' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Lock and select stock numbers
    const { rows: stock } = await client.query(
      `SELECT id FROM numbers WHERE range_id=$1 AND assigned_to IS NULL AND active=true
       ORDER BY id LIMIT $2 FOR UPDATE SKIP LOCKED`,
      [parseInt(range_id), parseInt(qty)]
    );
    if (stock.length < parseInt(qty)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Not enough stock. Only ${stock.length} available.` });
    }
    const ids = stock.map(r => r.id);
    const today = new Date().toISOString().slice(0,10);
    await client.query(
      `UPDATE numbers SET assigned_to=$1, assigned_date=$2, payterm=$3, payout=$4, sd_limit=$5, sw_limit=$6
       WHERE id = ANY($7)`,
      [parseInt(user_id), today, payterm||'Monthly15', parseFloat(payout)||0,
       parseInt(sd_limit)||0, parseInt(sw_limit)||0, ids]
    );
    // Log allocation
    const user  = await client.query(`SELECT username FROM accounts WHERE id=$1`, [user_id]);
    const range = await client.query(`SELECT name FROM ranges WHERE id=$1`, [range_id]);
    await client.query(
      `INSERT INTO alloc_log(user_id,username,range_id,range_name,qty,payout)
       VALUES($1,$2,$3,$4,$5,$6)`,
      [user_id, user.rows[0]?.username||'?', range_id, range.rows[0]?.name||'?', stock.length, parseFloat(payout)||0]
    );
    await client.query('COMMIT');
    res.json({ allocated: stock.length });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('[numbers/allocate]', err);
    res.status(500).json({ error: err.message });
  } finally { client.release() }
});

// GET /api/numbers/alloc-log — allocation history
router.get('/alloc-log', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(`SELECT * FROM alloc_log ORDER BY created_at DESC LIMIT 50`);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// PATCH /api/numbers/:id/unassign — return to stock
router.patch('/:id/unassign', auth, requireDev, async (req, res) => {
  try {
    await pool.query(
      `UPDATE numbers SET assigned_to=NULL,assigned_date=NULL,payterm=NULL,payout=NULL,sd_limit=0,sw_limit=0
       WHERE id=$1`, [req.params.id]
    );
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// PUT /api/numbers/:id — edit number settings
router.put('/:id', auth, requireDev, async (req, res) => {
  const { payterm, payout, sd_limit, sw_limit, active } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE numbers SET payterm=$1,payout=$2,sd_limit=$3,sw_limit=$4,active=$5 WHERE id=$6 RETURNING *`,
      [payterm, parseFloat(payout)||0, parseInt(sd_limit)||0, parseInt(sw_limit)||0, active!==false, req.params.id]
    );
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// DELETE /api/numbers/:id
router.delete('/:id', auth, requireAdmin, async (req, res) => {
  try {
    await pool.query(`DELETE FROM numbers WHERE id=$1`, [req.params.id]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

module.exports = router;
