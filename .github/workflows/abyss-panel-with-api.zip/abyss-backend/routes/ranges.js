const router  = require('express').Router();
const multer  = require('multer');
const pool    = require('../config/db');
const { auth, requireDev, requireAdmin } = require('../middleware/auth');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// Country prefix detection
const PREFIXES = [
  ['20','Egypt'],['212','Morocco'],['213','Algeria'],['216','Tunisia'],['218','Libya'],
  ['234','Nigeria'],['233','Ghana'],['251','Ethiopia'],['255','Tanzania'],['256','Uganda'],
  ['257','Burundi'],['27','South Africa'],['30','Greece'],['31','Netherlands'],['32','Belgium'],
  ['33','France'],['34','Spain'],['351','Portugal'],['353','Ireland'],['358','Finland'],
  ['36','Hungary'],['380','Ukraine'],['39','Italy'],['40','Romania'],['41','Switzerland'],
  ['420','Czech Republic'],['43','Austria'],['44','UK'],['45','Denmark'],['46','Sweden'],
  ['47','Norway'],['48','Poland'],['49','Germany'],['51','Peru'],['52','Mexico'],['54','Argentina'],
  ['55','Brazil'],['56','Chile'],['57','Colombia'],['60','Malaysia'],['61','Australia'],
  ['62','Indonesia'],['63','Philippines'],['65','Singapore'],['66','Thailand'],['7','Russia'],
  ['81','Japan'],['82','South Korea'],['84','Vietnam'],['86','China'],['880','Bangladesh'],
  ['90','Turkey'],['91','India'],['92','Pakistan'],['93','Afghanistan'],['961','Lebanon'],
  ['962','Jordan'],['963','Syria'],['964','Iraq'],['965','Kuwait'],['966','Saudi Arabia'],
  ['967','Yemen'],['971','UAE'],['972','Israel'],['973','Bahrain'],['974','Qatar'],['98','Iran'],
].sort((a,b) => b[0].length - a[0].length);

function detectCountry(num) {
  const n = String(num).replace(/\D/g,'');
  for (const [pfx,country] of PREFIXES) { if (n.startsWith(pfx)) return country; }
  return 'Unknown';
}
function detectPrefix(num) {
  const n = String(num).replace(/\D/g,'');
  for (const [pfx] of PREFIXES) { if (n.startsWith(pfx)) return pfx; }
  return n.slice(0,4);
}

// GET /api/ranges — list with stock info
router.get('/', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT r.*,
        COUNT(n.id)                                       AS total_numbers,
        COUNT(n.id) FILTER(WHERE n.assigned_to IS NULL)   AS stock,
        COUNT(n.id) FILTER(WHERE n.assigned_to IS NOT NULL) AS assigned
       FROM ranges r
       LEFT JOIN numbers n ON n.range_id = r.id
       GROUP BY r.id
       ORDER BY r.created_at DESC`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/ranges/:id/stock-sample — preview first 20 stock numbers
router.get('/:id/stock-sample', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT number FROM numbers WHERE range_id=$1 AND assigned_to IS NULL AND active=true
       ORDER BY id LIMIT 20`, [req.params.id]
    );
    res.json(rows.map(r => r.number));
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// POST /api/ranges/upload — create range + bulk import numbers from .txt
router.post('/upload', auth, requireDev, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const { name, country: manualCountry, prefix: manualPrefix, operator, default_payout, default_payterm } = req.body;
  if (!name) return res.status(400).json({ error: 'Range name required' });

  // Parse numbers from txt
  const lines = req.file.buffer.toString('utf8').split(/\r?\n/)
    .map(l => l.trim()).filter(l => /^\d{7,15}$/.test(l));
  const unique = [...new Set(lines)];
  if (!unique.length) return res.status(400).json({ error: 'No valid numbers found in file' });

  const firstNum = unique[0];
  const country = manualCountry || detectCountry(firstNum);
  const prefix  = manualPrefix  || detectPrefix(firstNum);

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Create range
    const rangeRes = await client.query(
      `INSERT INTO ranges(name,country,prefix,operator,default_payout,default_payterm)
       VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
      [name, country, prefix, operator||null, parseFloat(default_payout)||0, default_payterm||'Monthly15']
    );
    const range = rangeRes.rows[0];

    // Bulk insert numbers using COPY-like approach with unnest
    const nums = unique;
    let added = 0, skipped = 0;

    // Insert in batches of 5000
    const BATCH = 5000;
    for (let i = 0; i < nums.length; i += BATCH) {
      const batch = nums.slice(i, i + BATCH);
      const vals  = batch.map((n,j) => `($${j*6+1},$${j*6+2},$${j*6+3},$${j*6+4},$${j*6+5},$${j*6+6})`).join(',');
      const params = batch.flatMap(n => [range.id, range.name, n, prefix, country, true]);
      try {
        const r = await client.query(
          `INSERT INTO numbers(range_id,range_name,number,prefix,country,active)
           VALUES ${vals} ON CONFLICT(number) DO NOTHING`,
          params
        );
        added += r.rowCount;
        skipped += batch.length - r.rowCount;
      } catch (e) { skipped += batch.length; }
    }

    await client.query('COMMIT');
    res.status(201).json({ range, added, skipped, total: unique.length });
  } catch (err) {
    await client.query('ROLLBACK');
    if (err.code === '23505') return res.status(400).json({ error: 'Range name already exists' });
    console.error('[ranges/upload]', err);
    res.status(500).json({ error: err.message });
  } finally { client.release() }
});

// PUT /api/ranges/:id — edit range metadata
router.put('/:id', auth, requireDev, async (req, res) => {
  const { name, country, prefix, operator, default_payout, default_payterm } = req.body;
  const id = parseInt(req.params.id);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `UPDATE ranges SET name=$1,country=$2,prefix=$3,operator=$4,default_payout=$5,default_payterm=$6
       WHERE id=$7 RETURNING *`,
      [name, country, prefix, operator||null, parseFloat(default_payout)||0, default_payterm||'Monthly15', id]
    );
    // Update range_name in numbers
    await client.query(`UPDATE numbers SET range_name=$1,country=$2 WHERE range_id=$3`, [name, country, id]);
    await client.query('COMMIT');
    res.json(rows[0]);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally { client.release() }
});

// DELETE /api/ranges/:id — delete range + all numbers + their traffic
router.delete('/:id', auth, requireAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    await pool.query(`DELETE FROM ranges WHERE id=$1`, [id]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

module.exports = router;
