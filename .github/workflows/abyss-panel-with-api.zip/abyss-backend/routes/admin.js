const router = require('express').Router();
const bcrypt = require('bcryptjs');
const pool   = require('../config/db');
const { auth, requireDev, requireAdmin } = require('../middleware/auth');

// GET /api/admin/dev-codes
router.get('/dev-codes', auth, requireAdmin, async (req, res) => {
  try {
    const { rows } = await pool.query(`SELECT * FROM dev_codes ORDER BY id`);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// POST /api/admin/dev-codes
router.post('/dev-codes', auth, requireAdmin, async (req, res) => {
  const code = 'DEV-' +
    Math.random().toString(36).slice(2,6).toUpperCase() + '-' +
    Math.random().toString(36).slice(2,6).toUpperCase();
  try {
    const { rows } = await pool.query(
      `INSERT INTO dev_codes(code) VALUES($1) RETURNING *`, [code]
    );
    res.status(201).json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// DELETE /api/admin/dev-codes/:id
router.delete('/dev-codes/:id', auth, requireAdmin, async (req, res) => {
  try {
    await pool.query(`DELETE FROM dev_codes WHERE id=$1`, [req.params.id]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/admin/system-info
router.get('/system-info', auth, requireDev, async (req, res) => {
  try {
    const [accounts, ranges, numbers, stock, assigned, traffic] = await Promise.all([
      pool.query(`SELECT COUNT(*) FROM accounts`),
      pool.query(`SELECT COUNT(*) FROM ranges`),
      pool.query(`SELECT COUNT(*) FROM numbers`),
      pool.query(`SELECT COUNT(*) FROM numbers WHERE assigned_to IS NULL`),
      pool.query(`SELECT COUNT(*) FROM numbers WHERE assigned_to IS NOT NULL`),
      pool.query(`SELECT COUNT(*) FROM traffic`),
    ]);
    res.json({
      accounts:  parseInt(accounts.rows[0].count),
      ranges:    parseInt(ranges.rows[0].count),
      numbers:   parseInt(numbers.rows[0].count),
      stock:     parseInt(stock.rows[0].count),
      assigned:  parseInt(assigned.rows[0].count),
      traffic:   parseInt(traffic.rows[0].count),
    });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/admin/user-performance — ranking
router.get('/user-performance', auth, requireDev, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.id, a.username, a.name, a.active,
        COUNT(DISTINCT n.id)        AS nums,
        COALESCE(SUM(t.sms),0)      AS total_sms,
        COALESCE(SUM(t.payout),0)   AS total_payout,
        COUNT(t.id)                 AS sessions,
        MAX(t.recorded_at)          AS last_activity
       FROM accounts a
       LEFT JOIN numbers n ON n.assigned_to = a.id
       LEFT JOIN traffic t ON t.user_id = a.id
       WHERE a.role = 'user'
       GROUP BY a.id ORDER BY total_sms DESC`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

module.exports = router;
