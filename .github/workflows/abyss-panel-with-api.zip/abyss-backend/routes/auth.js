const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const pool    = require('../config/db');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
  try {
    const { rows } = await pool.query(`SELECT * FROM accounts WHERE username=$1`, [username]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const user = rows[0];
    if (!user.active) return res.status(403).json({ error: 'Account disabled' });
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    // Update last_login & login_count
    await pool.query(
      `UPDATE accounts SET last_login=NOW(), login_count=login_count+1 WHERE id=$1`, [user.id]
    );

    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    const { password: _, ...userSafe } = user;
    res.json({ token, user: userSafe });
  } catch (err) {
    console.error('[auth/login]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/auth/me
const { auth } = require('../middleware/auth');
router.get('/me', auth, (req, res) => {
  const { password: _, ...safe } = req.user;
  res.json(safe);
});

// PUT /api/auth/profile
router.put('/profile', auth, async (req, res) => {
  const { name, email, country, company, skype, contact, address } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE accounts SET name=$1,email=$2,country=$3,company=$4,skype=$5,contact=$6,address=$7
       WHERE id=$8 RETURNING id,username,role,name,email,country,company,skype,contact,address,active,created_at`,
      [name, email, country, company, skype, contact, address, req.user.id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error('[auth/profile]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/auth/password
router.put('/password', auth, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword || newPassword.length < 6)
    return res.status(400).json({ error: 'Invalid password data' });
  try {
    const { rows } = await pool.query(`SELECT password FROM accounts WHERE id=$1`, [req.user.id]);
    const valid = await bcrypt.compare(currentPassword, rows[0].password);
    if (!valid) return res.status(400).json({ error: 'Wrong current password' });
    const hash = await bcrypt.hash(newPassword, 12);
    await pool.query(`UPDATE accounts SET password=$1 WHERE id=$2`, [hash, req.user.id]);
    res.json({ ok: true });
  } catch (err) {
    console.error('[auth/password]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
