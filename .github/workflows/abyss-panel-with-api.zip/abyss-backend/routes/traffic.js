const router = require('express').Router();
const pool   = require('../config/db');
const { auth, requireDev } = require('../middleware/auth');

// GET /api/traffic — paginated, filterable
router.get('/', auth, async (req, res) => {
  const { user_id, from, to, q, page = 1, per = 25 } = req.query;
  const offset = (parseInt(page)-1) * parseInt(per);
  try {
    let where = [];
    let params = [];
    let pi = 1;

    // Users only see their own traffic
    if (req.user.role === 'user') {
      where.push(`t.user_id=$${pi++}`); params.push(req.user.id);
    } else if (user_id) {
      where.push(`t.user_id=$${pi++}`); params.push(parseInt(user_id));
    }
    if (from) { where.push(`t.recorded_at >= $${pi++}`); params.push(from + ' 00:00:00'); }
    if (to)   { where.push(`t.recorded_at <= $${pi++}`); params.push(to   + ' 23:59:59'); }
    if (q)    {
      where.push(`(t.number ILIKE $${pi} OR t.cli ILIKE $${pi} OR t.range_name ILIKE $${pi})`);
      params.push(`%${q}%`); pi++;
    }
    const wc = where.length ? 'WHERE ' + where.join(' AND ') : '';

    const { rows } = await pool.query(
      `SELECT t.*, a.username AS owner_username
       FROM traffic t
       LEFT JOIN accounts a ON a.id = t.user_id
       ${wc}
       ORDER BY t.recorded_at DESC
       LIMIT $${pi} OFFSET $${pi+1}`,
      [...params, parseInt(per), offset]
    );
    const totals = await pool.query(
      `SELECT COUNT(*) AS records, COALESCE(SUM(sms),0) AS total_sms, COALESCE(SUM(payout),0) AS total_payout
       FROM traffic t ${wc}`, params
    );
    const count = await pool.query(`SELECT COUNT(*) FROM traffic t ${wc}`, params);
    res.json({ rows, total: parseInt(count.rows[0].count), summary: totals.rows[0] });
  } catch (err) { console.error('[traffic GET]', err); res.status(500).json({ error: err.message }) }
});

// GET /api/traffic/stats/dashboard — quick stats for dashboard
router.get('/stats/dashboard', auth, async (req, res) => {
  const uid = req.user.role === 'user' ? req.user.id : null;
  const filter = uid ? `AND user_id=$1` : '';
  const params = uid ? [uid] : [];
  try {
    const today = new Date().toISOString().slice(0,10);
    const week  = new Date(Date.now() - 7*86400000).toISOString().slice(0,10);
    const month = new Date(Date.now() - 30*86400000).toISOString().slice(0,10);
    const [today_r, week_r, month_r, all_r] = await Promise.all([
      pool.query(`SELECT COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout FROM traffic WHERE recorded_at::date=${ uid?'$2':'$1'} ${filter}`, uid ? [uid, today] : [today]),
      pool.query(`SELECT COALESCE(SUM(sms),0) AS sms FROM traffic WHERE recorded_at >= ${ uid?'$2':'$1'} ${filter}`, uid ? [uid, week] : [week]),
      pool.query(`SELECT COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout FROM traffic WHERE recorded_at >= ${ uid?'$2':'$1'} ${filter}`, uid ? [uid, month] : [month]),
      pool.query(`SELECT COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout, COUNT(*) AS sessions FROM traffic WHERE 1=1 ${filter}`, params),
    ]);
    res.json({
      today_sms:    parseInt(today_r.rows[0].sms),
      today_payout: parseFloat(today_r.rows[0].payout),
      week_sms:     parseInt(week_r.rows[0].sms),
      month_sms:    parseInt(month_r.rows[0].sms),
      month_payout: parseFloat(month_r.rows[0].payout),
      all_sms:      parseInt(all_r.rows[0].sms),
      all_payout:   parseFloat(all_r.rows[0].payout),
      sessions:     parseInt(all_r.rows[0].sessions),
    });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/traffic/stats/chart?days=30 — daily breakdown
router.get('/stats/chart', auth, async (req, res) => {
  const days = Math.min(parseInt(req.query.days)||30, 365);
  const uid  = req.user.role === 'user' ? req.user.id : (req.query.user_id ? parseInt(req.query.user_id) : null);
  try {
    const { rows } = await pool.query(
      `SELECT recorded_at::date AS day, COALESCE(SUM(sms),0) AS sms, COALESCE(SUM(payout),0) AS payout
       FROM traffic
       WHERE recorded_at >= NOW() - INTERVAL '${days} days'
       ${uid ? 'AND user_id=$1' : ''}
       GROUP BY day ORDER BY day ASC`,
      uid ? [uid] : []
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/traffic/stats/hourly — heatmap data
router.get('/stats/hourly', auth, async (req, res) => {
  const uid = req.user.role === 'user' ? req.user.id : (req.query.user_id ? parseInt(req.query.user_id) : null);
  try {
    const { rows } = await pool.query(
      `SELECT EXTRACT(HOUR FROM recorded_at) AS hour, COALESCE(SUM(sms),0) AS sms
       FROM traffic WHERE 1=1 ${uid ? 'AND user_id=$1' : ''}
       GROUP BY hour ORDER BY hour`,
      uid ? [uid] : []
    );
    const result = Array(24).fill(0);
    rows.forEach(r => { result[parseInt(r.hour)] = parseInt(r.sms) });
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/traffic/stats/cli — CLI breakdown
router.get('/stats/cli', auth, async (req, res) => {
  const uid = req.user.role === 'user' ? req.user.id : (req.query.user_id ? parseInt(req.query.user_id) : null);
  try {
    const { rows } = await pool.query(
      `SELECT cli, SUM(sms) AS sms FROM traffic WHERE 1=1 ${uid ? 'AND user_id=$1' : ''}
       GROUP BY cli ORDER BY sms DESC LIMIT 8`,
      uid ? [uid] : []
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// GET /api/traffic/stats/numbers — per-number performance
router.get('/stats/numbers', auth, async (req, res) => {
  const uid = req.user.role === 'user' ? req.user.id : (req.query.user_id ? parseInt(req.query.user_id) : null);
  try {
    const { rows } = await pool.query(
      `SELECT number, range_name, SUM(sms) AS sms, SUM(payout) AS payout, COUNT(*) AS sessions
       FROM traffic WHERE 1=1 ${uid ? 'AND user_id=$1' : ''}
       GROUP BY number, range_name ORDER BY sms DESC LIMIT 20`,
      uid ? [uid] : []
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// POST /api/traffic — add traffic record (admin/dev only)
router.post('/', auth, requireDev, async (req, res) => {
  const { number_id, cli, sms, currency, payout, ip, recorded_at } = req.body;
  if (!number_id || !sms) return res.status(400).json({ error: 'number_id and sms required' });
  try {
    const num = await pool.query(`SELECT * FROM numbers WHERE id=$1`, [number_id]);
    if (!num.rows.length) return res.status(404).json({ error: 'Number not found' });
    const n = num.rows[0];
    const { rows } = await pool.query(
      `INSERT INTO traffic(user_id,number_id,number,range_name,cli,sms,currency,payout,ip,recorded_at)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [n.assigned_to, n.id, n.number, n.range_name, cli||'XXXXX', parseInt(sms),
       currency||'USD', parseFloat(payout)||(parseInt(sms)*(n.payout||0)),
       ip||null, recorded_at ? new Date(recorded_at) : new Date()]
    );
    res.status(201).json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// DELETE /api/traffic/:id
router.delete('/:id', auth, requireDev, async (req, res) => {
  try {
    await pool.query(`DELETE FROM traffic WHERE id=$1`, [req.params.id]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

// DELETE /api/traffic — clear all (superadmin only)
router.delete('/', auth, async (req, res) => {
  if (req.user.role !== 'superadmin') return res.status(403).json({ error: 'Superadmin only' });
  try {
    await pool.query(`DELETE FROM traffic`);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }) }
});

module.exports = router;
