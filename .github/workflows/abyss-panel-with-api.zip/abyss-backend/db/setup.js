require('dotenv').config({ path: require('path').join(__dirname,'../.env') });
const { Pool } = require('pg');
const bcrypt   = require('bcryptjs');

const pool = new Pool({
  host: process.env.DB_HOST||'localhost', port: parseInt(process.env.DB_PORT)||5432,
  database: process.env.DB_NAME||'abyss_panel',
  user: process.env.DB_USER||'abyss_user', password: process.env.DB_PASSWORD
});

async function run(){
  const c = await pool.connect();
  try {
    console.log('[DB] Creating tables...');
    await c.query(`
      CREATE TABLE IF NOT EXISTS accounts(
        id SERIAL PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL, role VARCHAR(20) NOT NULL DEFAULT 'user'
          CHECK(role IN('superadmin','dev','user')),
        name VARCHAR(100), email VARCHAR(100), country VARCHAR(60),
        company VARCHAR(100), skype VARCHAR(60), contact VARCHAR(60), address TEXT,
        active BOOLEAN DEFAULT true, created_at TIMESTAMPTZ DEFAULT NOW(),
        last_login TIMESTAMPTZ, login_count INTEGER DEFAULT 0);`);

    await c.query(`
      CREATE TABLE IF NOT EXISTS dev_codes(
        id SERIAL PRIMARY KEY, code VARCHAR(50) UNIQUE NOT NULL,
        used BOOLEAN DEFAULT false, used_by INTEGER REFERENCES accounts(id),
        created_at TIMESTAMPTZ DEFAULT NOW());`);

    await c.query(`
      CREATE TABLE IF NOT EXISTS ranges(
        id SERIAL PRIMARY KEY, name VARCHAR(200) UNIQUE NOT NULL,
        country VARCHAR(60), prefix VARCHAR(20), operator VARCHAR(100),
        default_payout NUMERIC(10,4) DEFAULT 0, default_payterm VARCHAR(30) DEFAULT 'Monthly15',
        created_at TIMESTAMPTZ DEFAULT NOW());`);

    await c.query(`
      CREATE TABLE IF NOT EXISTS numbers(
        id SERIAL PRIMARY KEY, range_id INTEGER NOT NULL REFERENCES ranges(id) ON DELETE CASCADE,
        range_name VARCHAR(200), number VARCHAR(20) UNIQUE NOT NULL,
        prefix VARCHAR(20), country VARCHAR(60),
        assigned_to INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
        assigned_date DATE, payterm VARCHAR(30), payout NUMERIC(10,4),
        sd_limit INTEGER DEFAULT 0, sw_limit INTEGER DEFAULT 0,
        active BOOLEAN DEFAULT true, added_at TIMESTAMPTZ DEFAULT NOW());
      CREATE INDEX IF NOT EXISTS idx_num_range ON numbers(range_id);
      CREATE INDEX IF NOT EXISTS idx_num_user  ON numbers(assigned_to);
      CREATE INDEX IF NOT EXISTS idx_num_num   ON numbers(number);`);

    await c.query(`
      CREATE TABLE IF NOT EXISTS traffic(
        id SERIAL PRIMARY KEY,
        user_id   INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
        number_id INTEGER REFERENCES numbers(id)  ON DELETE SET NULL,
        number VARCHAR(20), range_name VARCHAR(200), cli VARCHAR(50),
        sms INTEGER DEFAULT 0, currency VARCHAR(5) DEFAULT 'USD',
        payout NUMERIC(10,4) DEFAULT 0, ip VARCHAR(45),
        recorded_at TIMESTAMPTZ DEFAULT NOW());
      CREATE INDEX IF NOT EXISTS idx_trf_user ON traffic(user_id);
      CREATE INDEX IF NOT EXISTS idx_trf_num  ON traffic(number);
      CREATE INDEX IF NOT EXISTS idx_trf_date ON traffic(recorded_at);`);

    await c.query(`
      CREATE TABLE IF NOT EXISTS targets(
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
        type VARCHAR(20) NOT NULL CHECK(type IN('daily','monthly')),
        value INTEGER DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT NOW(),
        UNIQUE(user_id,type));`);

    await c.query(`
      CREATE TABLE IF NOT EXISTS alloc_log(
        id SERIAL PRIMARY KEY,
        user_id   INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
        username  VARCHAR(50),
        range_id  INTEGER REFERENCES ranges(id)   ON DELETE SET NULL,
        range_name VARCHAR(200), qty INTEGER, payout NUMERIC(10,4),
        created_at TIMESTAMPTZ DEFAULT NOW());`);

    // Default dev codes
    for(const code of ['DEV-2024-ABYSS','DEV-ELITE-001','DEV-MASTER-99']){
      await c.query(`INSERT INTO dev_codes(code) VALUES($1) ON CONFLICT DO NOTHING`,[code]);
    }

    // Superadmin
    const existing = await c.query(`SELECT id FROM accounts WHERE role='superadmin' LIMIT 1`);
    if(existing.rowCount === 0){
      const u = process.env.SUPERADMIN_USERNAME||'superadmin';
      const p = process.env.SUPERADMIN_PASSWORD||'Admin@2024!';
      const h = await bcrypt.hash(p,12);
      await c.query(
        `INSERT INTO accounts(username,password,role,name,email,country,active)
         VALUES($1,$2,'superadmin','Super Administrator','admin@abyss.panel','Egypt',true)`,[u,h]);
      console.log(`[DB] Superadmin created: ${u} / ${p}`);
    } else {
      console.log('[DB] Superadmin already exists');
    }
    console.log('[DB] Setup complete!');
  } finally { c.release(); await pool.end(); }
}
run().catch(e=>{ console.error('[DB] Error:', e.message); process.exit(1) });
