/**
 * Migration: Add api_keys table
 * Run: node db/migrate_apikeys.js
 */
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { Pool } = require('pg');

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME     || 'abyss_panel',
  user:     process.env.DB_USER     || 'abyss_user',
  password: process.env.DB_PASSWORD,
});

async function run() {
  const client = await pool.connect();
  try {
    console.log('[Migration] Adding api_keys table...');

    await client.query(`
      CREATE TABLE IF NOT EXISTS api_keys (
        id            SERIAL PRIMARY KEY,
        user_id       INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
        key_value     VARCHAR(60) UNIQUE NOT NULL,
        label         VARCHAR(100) NOT NULL DEFAULT 'My Key',
        scope         VARCHAR(10) NOT NULL DEFAULT 'read'
                        CHECK(scope IN('read','write','full')),
        active        BOOLEAN NOT NULL DEFAULT true,
        last_used     TIMESTAMPTZ,
        request_count INTEGER NOT NULL DEFAULT 0,
        expires_at    TIMESTAMPTZ,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_apikey_value   ON api_keys(key_value);
      CREATE INDEX IF NOT EXISTS idx_apikey_user    ON api_keys(user_id);
    `);

    console.log('[Migration] ✅ api_keys table created successfully!');
    console.log('[Migration] Scopes available: read | write | full');
    console.log('[Migration] Done.');
  } catch (err) {
    console.error('[Migration] ❌ Error:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

run();
