# ABYSS PANEL — Backend Setup Guide

## 1. Requirements
- Ubuntu 20.04+ VPS
- Node.js 18+
- PostgreSQL 14+

## 2. Install Dependencies on VPS

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install PM2 (process manager)
sudo npm install -g pm2
```

## 3. Setup PostgreSQL

```bash
# Switch to postgres user
sudo -u postgres psql

# Inside PostgreSQL shell:
CREATE DATABASE abyss_panel;
CREATE USER abyss_user WITH ENCRYPTED PASSWORD 'your_strong_password_here';
GRANT ALL PRIVILEGES ON DATABASE abyss_panel TO abyss_user;
\c abyss_panel
GRANT ALL ON SCHEMA public TO abyss_user;
\q
```

## 4. Upload & Configure Backend

```bash
# Upload the backend folder to your VPS (e.g., /var/www/abyss-panel/)
scp -r abyss-backend/ user@YOUR_VPS_IP:/var/www/abyss-panel/

# SSH into VPS
ssh user@YOUR_VPS_IP
cd /var/www/abyss-panel/

# Copy .env.example to .env and edit it
cp .env.example .env
nano .env
# Fill in: DB_PASSWORD, JWT_SECRET (random 32+ chars), SUPERADMIN_PASSWORD
```

## 5. Install & Run

```bash
# Install npm packages
npm install

# Run database setup (creates tables + superadmin)
npm run setup-db

# Start with PM2
pm2 start server.js --name abyss-panel
pm2 save
pm2 startup
```

## 6. Put Frontend HTML

```bash
mkdir -p public
# Copy abyss-panel-v2.html to public/index.html
cp abyss-panel-v2.html public/index.html
```

## 7. Nginx Reverse Proxy (optional but recommended)

```bash
sudo apt install -y nginx
sudo nano /etc/nginx/sites-available/abyss-panel
```

```nginx
server {
    listen 80;
    server_name your-domain.com;  # or your VPS IP

    client_max_body_size 100M;  # for large .txt uploads

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/abyss-panel /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 8. SSL with Let's Encrypt (optional)
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 9. Useful PM2 Commands
```bash
pm2 logs abyss-panel       # View logs
pm2 restart abyss-panel    # Restart
pm2 stop abyss-panel       # Stop
pm2 status                 # Check status
```

## Default Credentials
- Superadmin: set in .env → SUPERADMIN_USERNAME / SUPERADMIN_PASSWORD
- Default Dev Codes: DEV-2024-ABYSS / DEV-ELITE-001 / DEV-MASTER-99
