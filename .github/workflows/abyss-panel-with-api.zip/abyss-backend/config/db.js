require('dotenv').config({ path: require('path').join(__dirname,'../.env') });
const { Pool } = require('pg');

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME     || 'abyss_panel',
  user:     process.env.DB_USER     || 'abyss_user',
  password: process.env.DB_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => console.error('[DB] Pool error:', err.message));

module.exports = pool;
